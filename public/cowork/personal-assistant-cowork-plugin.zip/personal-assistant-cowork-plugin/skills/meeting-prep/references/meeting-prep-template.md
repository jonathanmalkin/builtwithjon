# Meeting Prep — [Meeting Title]

[HH:MM AM/PM, Day Month D] · [location or link] · [duration]

## Who's in the room

- [Name, role, company] — [one-line context: how you know them, why they matter]
- [...]

## What this meeting is about

[One or two sentences. Pull from the event description; sharpen it.]

## What each party needs

- **You need:** [1–2 things — a decision, an answer, a commitment]
- **They need:** [1–2 things — what they're hoping to get out of this]

## Your opener

[A specific opener tied to actual context — a recent thing they did, an unresolved thread, the explicit reason for the meeting. Not generic small talk.]

## Open threads going in

- [Thread / commitment / question still hanging]
- [...]

## Questions to ask

- [The question you might forget to ask without this brief]
- [...]

## What to walk out with

[The single artifact, decision, or next step that makes this meeting a success.]

## Risks

- [Anything from the research that could derail the conversation]
- Approval boundary: nothing in this meeting commits you to an external action without explicit confirmation.
