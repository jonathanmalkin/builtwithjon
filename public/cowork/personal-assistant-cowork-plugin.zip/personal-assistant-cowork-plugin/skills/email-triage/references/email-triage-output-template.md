# Inbox Triage — [Date, Time]

[N] threads reviewed.

Gmail drafts created: [created count]/[draftable Reply Needed count]. [Open Gmail Drafts](https://mail.google.com/mail/u/0/#drafts)
Voice source: [voice.md — email setup / generic defaults — voice setup cancelled]

## Reply Needed ([count])

### [Subject] — [Sender, Time]

[Two-line context: what the thread is about, what's unresolved.]

**Gmail draft:** [Created / Not created / Skipped — reason if not created.]

**Draft reply shown here too:**

> [The draft as saved to Gmail Drafts, ready for the user to review and send.]

[If anything is missing for you to fill in, name it.]

---

### [Next Reply Needed thread]

...

## FYI ([count])

- [Subject] — [one-line summary] — [Sender, Time]
- [...]

## Archived ([count])

[Counts only — no per-thread lines unless something is unusual.]

## Ignored ([count])

[Counts only.]

---

*Drafts marked Created were saved to Gmail Drafts and are also printed above for review. Open Gmail Drafts: [Open Gmail Drafts](https://mail.google.com/mail/u/0/#drafts). Nothing was sent.*
