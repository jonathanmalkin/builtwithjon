# Voice Setup

Loaded from `email-triage/SKILL.md` Step 2 when `workspace/Agenda/voice.md` is missing or incomplete. Sets up the user's email-specific voice profile before any reply drafting happens.

The default path scans the user's sent folder and asks three follow-up questions. A scan-free interview fallback is available for users who decline.

---

## 1 — Privacy gate (required before any scan)

Before reading any sent email, present this consent prompt exactly:

> Before I draft replies, I need to learn how you actually write emails. Otherwise the drafts will sound like AI.
>
> The best signal is your own sent folder. I'd like to read a sample of your recent sent emails (default: the last 100, excluding forwards, one-word replies, automated messages, and anything that doesn't look like *you* writing). I'll extract patterns — greetings, sign-offs, length, sample replies — and save them locally to `workspace/Agenda/voice.md`. You'll review the file before I use it.
>
> **Important: reading those emails sends their contents to Anthropic for processing.** Same as any other content you share with Claude. The extracted voice file stays local in your Project. Anthropic's standard data handling applies to the email contents passing through the model.
>
> Three options:
> 1. **Yes, scan my sent folder** (recommended — best voice match, ~3 minutes plus 3 quick questions)
> 2. **Interview only — don't read my email** (~8 minutes, 7 questions, weaker match)
> 3. **Cancel** — I'll skip voice setup and use generic defaults (drafts will be less personalized)

Wait for the user's choice. Do not begin the scan until they explicitly choose option 1.

- If **option 1:** continue to section 2.
- If **option 2:** skip to section 5 (full 7-question interview).
- If **option 3:** stop voice setup. Email-triage's Step 5 fallback block handles the no-voice case.

## 2 — Scan and filter the sent folder

Pull the user's last 50 sent emails (or the most recent 50 in the last 12 months, whichever is smaller). Apply these filters **before** extracting voice patterns. Keep an email only if it passes every filter.

**Filter out (do not use for voice extraction):**

- **Forwards** — subject starts with "Fwd:" / "FW:" / "Fw:" or body begins with quoted forwarded headers.
- **One-word and confirmation-only replies** — body is under ~5 words ("Thanks", "ok", "Got it", "Sounds good"). These reveal a habit but not range.
- **Auto-sends and out-of-office** — "Out of office," "I'm currently away," vacation responders, calendar invite auto-replies.
- **Mailing list / newsletter sends** — bulk emails sent to large distribution lists (>10 recipients), unsubscribe footers, marketing template HTML.
- **Pure logistics / no-prose** — replies that are only a link, only an attachment with no body, only "see attached," or only meeting times pasted from calendar.
- **Quoted-text-heavy replies where the user's own contribution is under 2 sentences.** Strip the quoted thread before deciding.
- **System-generated sends** — calendar invite ACKs, e-signature confirmations, automated "I shared a file with you" emails.
- **Drafts that were never actually sent** — if the connector returns drafts, exclude them.
- **Anything from before a date the user names** — if the user says "ignore emails older than X," honor it. People's voice shifts over time; the recent corpus is more representative.

**Keep (good signal for voice extraction):**

- Replies the user composed themselves with at least 2 sentences of original prose.
- New outbound emails the user started (not replies).
- A mix across relationship registers — work peers, vendors, family, cold contacts. If the corpus is heavily skewed to one register (e.g., 90 of 100 are to the same person), tell the user and offer to widen the date range.

**Hold-back rule:** if filtering leaves fewer than 10 usable emails, tell the user the corpus is too thin and ask whether to (a) widen the date range, (b) lower the minimum to 15 with a quality caveat in the voice file, or (c) fall back to the interview-only path. Do not extract voice from fewer than 15 emails.

Report briefly to the user: "Scanned X emails, kept Y after filtering. Extracting voice patterns now."

## 3 — Extract voice patterns from the corpus

Read `_voice.md` (sibling file in this references folder) for the target structure. Fill each section from the filtered corpus:

- **Greeting and sign-off:** identify the most common greeting and sign-off patterns. If they vary by recipient, note the variation.
- **Default length:** report the median sentence count and word count across the corpus. Note the typical range (e.g., "1-4 sentences, median 2").
- **Warmth by relationship:** group the corpus by recipient type if possible (frequent contacts = close; professional domains = neutral; first-time recipients = cold) and describe what shifts across the groups.
- **How they say no, defer, push back:** search the corpus for replies containing "can't," "won't," "unfortunately," "instead," "later," "next week," "let me get back," "rain check" and similar declines/deferrals. Pull 2-3 verbatim examples.
- **Phrases I never use (AI tells):** this section stays empty from the corpus alone — absence is ambiguous. Filled by the augmentation in section 4.
- **Punctuation and rhythm:** count em-dash, semicolon, contraction, and exclamation-point usage across the corpus. Report dominant habits (e.g., "Em-dashes appear in 4 of 87 emails — sparingly used").
- **Sample replies (verbatim):** pick three representative emails — one to a close contact, one professional, one where the user said no or pushed back. Lightly anonymize names and any obvious sensitive details (replace with [Name] / [Company] / [Amount] etc.). Preserve the writing verbatim otherwise.

Set the `Source:` line to: `sent-email corpus (N=Y after filtering, date range [oldest] to [newest]) + 3-question augmentation`.

## 4 — Three-question augmentation (corpus path only)

Sent email reveals patterns but can't reveal the negative space (what the user *avoids*) or stated rules going forward. Ask these three, one at a time. Wait for each answer.

**Q1 — Banned phrases / AI tells**

> What phrases would immediately make an email *not* sound like you? The kind of thing that if I drafted it, you'd know AI wrote it. Name as many as come to mind.
>
> If you're stuck: "Hope this finds you well," "Just circling back," "I wanted to reach out," "Please don't hesitate to," "As discussed" — do any of those make you cringe? Which ones do you actually use?

Fill the **Phrases I never use** section from the answer.

**Q2 — Anything to change going forward**

> Looking at the patterns I just pulled from your sent mail — is there anything you'd like to change going forward? E.g., "I write too long, please make me shorter" or "I'm too apologetic, cut the 'sorry's"?

Note the answer under a new line at the end of the **Default length** or **Punctuation and rhythm** section, prefixed with `Override:`. Do not edit the corpus-derived findings — keep both visible.

**Q3 — Warmth dial check**

> Quick check on warmth: I grouped your contacts into close / professional / cold based on the corpus. Are there specific people in your life — by name or relationship — where you write very differently than the group they'd land in? E.g., a boss who's a close friend, or a family member you keep things formal with?

Append named exceptions to the **Warmth by relationship** section.

Skip to section 6 (save and confirm).

## 5 — Interview-only path (corpus declined)

Reached from section 1 option 2. Run the full 7-question interview. Ask one at a time. Wait for each answer. Reflect back what you heard in one short sentence before moving on. Push back on vague answers — ask for verbatim examples whenever you can.

**Q1 — Greeting and sign-off**
> How do you actually start and end emails? Type out a greeting and sign-off the way you'd really write them, not the way you think you should. Pick someone you email regularly.

**Q2 — Default length**
> When you reply to a normal work email, are you usually writing one line, two or three sentences, or a full paragraph? Show me a recent reply that's typical.

**Q3 — Warmth by relationship**
> Pick three people you email regularly — one you're close to, one professional or neutral, one cold or formal. For each, tell me the one thing that's different about how you write to them.

**Q4 — Saying no, deferring, pushing back**
> How do you say no in an email when you can't or won't do something? Give me an actual recent example. And how do you push a meeting or ask for more time?

**Q5 — Phrases you'd never use**
> What phrases would immediately make an email *not* sound like you?

**Q6 — Punctuation and rhythm**
> Quick fire. Em-dashes — use them, hate them, indifferent? Contractions — 'don't' or 'do not'? Exclamation points — when, if ever?

**Q7 — Three real replies**
> Paste in three recent emails you've sent — one to someone you're close to, one to someone professional, one where you said no or pushed back. Don't clean them up.

Set the `Source:` line to `interview only — sent-email scan declined`.

## 6 — Save, review, confirm

Save the filled template as `workspace/Agenda/voice.md`. Set the `Last updated` date. Where a section can't be filled, leave a short bracketed prompt like `[no banned phrases captured yet]` rather than inventing content.

Read the file back to the user and ask: "Anything off, or anything you'd like to change before I use this?" Apply corrections, then return control to `SKILL.md` Step 3.

Tell the user the file is saved at `workspace/Agenda/voice.md`, that it's theirs to edit any time, and that if they ever want a deeper version covering posts, articles, and long-form writing, Chrissy Cowdrey's *AI Voice DNA Interview* is the 100-question version that takes about two hours.
