# Voice — how I write email

How I actually write emails, so the `email-triage` skill drafts replies that sound like me and not like AI. Filled when `email-triage` finds `voice.md` missing or incomplete, primarily from a scan of my own recent sent emails, with three short clarifying questions for the things sent mail can't reveal.

Last updated: [YYYY-MM-DD]
Source: [pick one — `sent-email corpus (N=___, date range ___ to ___) + 3-question augmentation` OR `interview only — sent-email scan declined`]

---

## Greeting and sign-off

How I actually open and close emails. Verbatim, not "what I should write."

- **Greeting:** [e.g., "Hey Sarah —" / "Sarah," / first name only / no greeting]
- **Sign-off:** [e.g., "Thanks," / "—J" / initials / nothing]

## Default length

What a typical reply looks like for me.

- **Default range:** [e.g., "1-3 sentences. Single line for confirmations. Full paragraph only when the topic warrants it."]
- **Example of a typical reply:** [paste one verbatim]

## Warmth by relationship

The dial. Same person writes differently to different people — capture the variation.

- **Close / peers:** [what shifts — greeting, length, contractions, do I say please]
- **Professional / neutral:** [what shifts]
- **Cold / formal / first contact:** [what shifts]

## How I say no, defer, push back

The replies most likely to read fake when AI-drafted. Verbatim examples preferred.

- **Saying no:** [example or pattern]
- **Pushing a meeting or asking for more time:** [example or pattern]
- **Asking for clarification:** [example or pattern]

## Phrases I never use (AI tells for me)

Hard rule. Any phrase here is a "do not write" instruction for every draft.

- [phrase]
- [phrase]
- [phrase]

## Punctuation and rhythm

Small markers that accumulate.

- **Em-dashes:** [hate / use sparingly / use freely]
- **Contractions:** [always / never / mixed]
- **Exclamation points:** [never / when excited / when matching their energy]
- **Other:** [anything else worth noting — semicolons, Oxford commas, fragments]

## Sample replies (verbatim)

The most important section. Three real recent replies, unedited.

### Sample 1 — to someone close

```
[paste verbatim]
```

### Sample 2 — to someone professional / neutral

```
[paste verbatim]
```

### Sample 3 — where I said no, deferred, or pushed back

```
[paste verbatim]
```

---

## How email-triage uses this file

When drafting replies, the skill reads this file and applies it concretely:

1. Open with my greeting pattern. Don't substitute "Hi" if I use first-name-only or no greeting.
2. Close with my sign-off. Don't add "Best regards," if I sign off with my initial.
3. Match my default length. Save longer drafts for threads that genuinely warrant it.
4. Calibrate warmth from the relationship — pick the closest match from the dial.
5. Never use a phrase from the "never use" list. Hard rule.
6. Match my punctuation habits.
7. Use the sample replies as the dominant style signal. When in doubt about phrasing, ask "would this fit in the three samples?"
