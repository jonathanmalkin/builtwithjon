# Morning Brief — [Day, Month D]

## Today

- [HH:MM AM/PM] — [meeting / event] — [short note]
- [HH:MM AM/PM] — [...]

## Meeting prep

- [time — meeting] — [the one thing to walk in knowing, or "see brief in Project files"]

## Threads needing attention

- [subject / sender] — [unresolved question]

## First move

[One concrete action, under 15 minutes if possible. Tie it to a goal where you can.]

## Goal progress

- [Goal 1 from USER.md] — [one honest line: moving, stalled, or untouched]
- [Goal 2] — [...]
- [Goal 3] — [...]

## Waiting on others

- [person] — [what, since when]

## Watch-outs

- [things that could go wrong, profile-relevant risks]
- Approval boundary: agent may save this finished Morning Brief report as HTML and text, and may leave it in this Cowork/Dispatch session. No email, calendar edit, public post, or message to anyone else without explicit approval.

*Data freshness: [only include if something was degraded — e.g., Calendar not exposed in this session, Gmail needs permission]*
*Outputs: [HTML path] and [TXT path]. Delivery: [left in Cowork/Dispatch session / sent to configured personal destination if available]*
