---
name: setup
description: Use when the user invokes /setup or asks to set up, install, configure, get started with, or refresh their personal assistant. The single setup path, end to end - it interviews the user and writes their profile, connects and discovers Gmail/Google Calendar, deploys the live Daily Brief artifact, and creates the weekday morning scheduled task. Re-running it later refreshes the profile.
---

# Setup

Take the user from "plugin installed" to "fully running" in one pass. Do the work
yourself; only ask the user what you genuinely need. Keep them posted with a
short line per step.

By the end the Project root holds `CLAUDE.md`, `USER.md`, `now.md`,
`decision-log.md` (no `workspace/` folder), the Daily Brief artifact is live, and
the weekday morning task is scheduled (8:00 AM by default). The user runs the
scheduled task once from the Scheduled menu after setup so Claude can collect
standing permission for daily runs.

**Boundary (installed, never relaxed):** read freely, draft freely, write local
Project files, and text the user *their own* brief. Never send email to others,
post, delete, buy, or change calendar events. Gmail **drafts** and the user's
**own** iMessage notification are the only outbound writes. Dispatch is the only
inbound path; iMessage is one-way to the user; Telegram is an advanced/custom
channel, not the basic setup path.

## Step 1 - Detect, then ask just two things

Check the environment first, ask only what's left:

- **Timezone:** detect from the locale/environment; default the morning run to
  **8:00 AM** weekdays there. Only ask if you truly can't detect it.
- **iMessage:** check whether the **Read and Send iMessages** connector exists
  (alias `iMessage`, `Messages`). Only ask for the phone number or email address
  associated with iMessage **if it does**; otherwise skip it (the brief still
  lands in the Project and `outputs/`, and you can note they can add the
  connector later for texts).

Then ask, in one short message, only:

1. **Assistant name** - suggest the Project name if you can see it.
2. **Your top 2-3 goals for the next 90 days**, and the project serving each.

That's the whole interview - keep it that short. Don't ask for tone or operating
overrides (the `CLAUDE.md` defaults stand), and don't run a long profile
interview. Everything else (people, week shape, deeper goal detail) the assistant
fills in over time via `capture`, or the user can re-run `setup`. Confirm name,
timezone, 8:00 AM, goals, and text choice in one line, then go.

## Step 2 - Write the profile files

Fill the `references/` templates from what you have and write to the **Project
root**, leaving bracketed prompts (`[no people captured yet]`) where the user
gave nothing - never fabricate:

- `CLAUDE.md` from `references/_CLAUDE.md` (replace the name; keep shipped
  tone/behavior defaults as-is).
- `USER.md` from `references/_USER.md` (identity + the goals; bracket the rest).
- `now.md` from `references/now-file-template.md`;
  `decision-log.md` from `references/decision-log-template.md`.

**Instructions:** the user already pasted the short generic instructions block
into the Project's Instructions field when they created the Project (per
Start-Here), and that block tells you to read these root files - so you do not
need them to paste anything now. The `CLAUDE.md` you just wrote is the durable,
detailed instruction layer the Project Instructions point at. If you find the
Project has no instructions pasted at all (e.g. they skipped Start-Here), show
the contents of `references/cowork-project-instructions.md` in a copy block and
ask them to paste it into their Project's Instructions field once.

## Step 3 - Wire everything up

Do this stretch yourself, narrating briefly. Three parts:

**a) Discover the connector tool names.** The artifact and the task call
connectors by fully-qualified names embedding a per-user server id
(`mcp__<id>__list_events`, `mcp__<id>__list_drafts`) - **different for every
user**. Discover them per the `CLAUDE.md` "Connector and delivery discovery"
procedure (active list -> deferred list + aliases `Gmail`/`mail`,
`Google Calendar`/`gcal` -> load schema -> harmless probe) and record two names
**verbatim**: `__CAL_TOOL__` (Calendar `list_events`) and `__DRAFTS_TOOL__`
(Gmail `list_drafts`). Confirm the accounts ("Found Gmail name@... and Calendar
X - use these?") so you don't wire up the wrong inbox. If one is missing, walk
them through Customize -> Connectors -> + -> Browse connectors -> Connect, then
resume; mention Workspace-admin enablement only on a permission error.

**b) Deploy the Daily Brief artifact** from `assets/daily-brief.template.html`
(Sunsama theme, two connectors, no AI inference): replace all four tokens
(`__USER_NAME__`, `__TZ__`, `__CAL_TOOL__`, `__DRAFTS_TOOL__`). Leave the shipped
sample `CTX` object as-is at deploy time - do not fabricate one from the
near-empty `now.md`; the first task run from the Scheduled menu overwrites `CTX`
with real data.
**`node --check` the extracted `<script>` and only deploy if it passes** (one
stray character crashes the page); then `create_artifact`, title "Daily Brief",
and **keep the artifact id**. When Claude prompts to create the artifact, tell
the user to click **Create**. The shipped template stays tokenized - only this
deployed copy gets real values.

**c) Schedule the weekday task** with `create_scheduled_task`, taskId
`daily-brief-refresh`, cron `0 8 * * 1-5` (cron runs in the user's local time, so
use 8:00 AM directly - no UTC conversion - unless they chose another time). When
Claude prompts to create the scheduled task, tell the user to click **Create**.
The run has no memory of this chat, so make the prompt **fully self-contained** -
bake in the assistant name, timezone, the **artifact id**, the two tool names,
and the notify choice + iMessage destination, and name the exact paths it
reads/writes:
`now.md`, `USER.md`, `voice.md`, `outputs/`, `meetings/`, `contacts/` in the
Project root. The prompt should, in order:

1. Run `meeting-prep` for today + tomorrow (HTML/TXT to `outputs/`, update
   `meetings/`/`contacts/`).
2. Run `email-triage` on the last 48h - **create Gmail drafts only, never
   send**. Use `voice.md` for tone **if it exists; if not, proceed without it**
   (do not stop).
3. Compose a 48-hour brief from `now.md`, `USER.md`, the calendar, and the
   triage.
4. If texts are on, send the brief to the user's **own** configured iMessage
   number or email only.
5. **Refresh the artifact's `CTX`**: load the artifact by its id, replace the
   `var CTX = {...}` object in the `<script>` with fresh JSON (`meetingPrep`,
   `goals`, `todos`, `parkedNote`, `waiting`; https-only links, never `file://`).
   Each `meetingPrep` item carries both a one-line excerpt (`meetingBriefText` /
   `contactBriefText`) and the complete briefing (`meetingBriefFull` /
   `contactBriefFull`) inlined as a JSON string from the meeting-prep output and
   `contacts/<file>.md` (strip frontmatter; keep markdown — the artifact renders
   headers, bullets, bold, and links). The sandbox can't read local files at open
   time, so the full briefing must live inside `CTX`. Run `node --check` on the
   modified script, and only then `update_artifact` with that id. Skip the update
   if the check fails, and note it.
6. Ask nothing during the run; note any gaps.

It uses the user's default model - no model step. (Scheduled tasks run only while
the app is open.) Do **not** run the task yourself during setup; the Start-Here
flow has the user run it from the Scheduled menu immediately afterward and
approve all permissions there.

## Done

Recap in a few lines: assistant name and files written; connectors live; Daily
Brief is live (schedule + drafts refresh on open, the rest each weekday morning);
the task runs weekdays at [time]; tell the user to open **Scheduled** in the left
sidebar, select **Daily Brief Refresh**, click **Run Now**, select the session
that starts, and approve all permissions so it can run daily; re-run `setup`
anytime to refresh; and the boundary - read, draft, notify-myself only.
