# Decision Log

Durable decisions, newest first. The agent appends here during normal conversation when you make a call that should stick. This is not a task list — it's the record of what was decided and why, so future-you and the assistant don't relitigate it.

Each entry: the date, the decision as an outcome, and one line of why.

---

## [YYYY-MM-DD] — [the decision, stated as an outcome]

[One or two sentences: why this was decided, and what it changes.]

---

<!-- New entries go directly below this line, above older ones. -->
