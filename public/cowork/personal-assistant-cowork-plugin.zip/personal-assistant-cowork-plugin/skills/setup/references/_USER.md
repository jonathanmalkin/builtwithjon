# USER

The source of truth for who I am and what I'm working toward. Every skill in this Project reads it. The `morning-brief` skill reads the Goals section below to report progress every day — keep it concrete.

Last updated: [YYYY-MM-DD]

## Identity

- Name: [full name]
- Occupation / role / what I do: [one or two lines]
- Where I'm based: [city / region]

## Goals — next 90 days

My two or three goals for the quarter, each with the active project serving it and how progress is measured. The morning brief reads this section and reports where I stand against each goal every day — so make each one concrete enough that a day of calendar and email could plausibly show movement.

### Goal 1: [the goal, stated as an outcome]

- **Project serving it:** [the concrete work happening now that moves this goal]
- **What "done" looks like:** [the finish line]
- **How progress shows up:** [what a day of movement looks like — e.g., "meetings booked", "draft sections completed", "replies sent to prospects"]

### Goal 2: [the goal]

- **Project serving it:** [...]
- **What "done" looks like:** [...]
- **How progress shows up:** [...]

### Goal 3: [the goal — optional, two is fine]

- **Project serving it:** [...]
- **What "done" looks like:** [...]
- **How progress shows up:** [...]

Anything not tied to one of these goals is a "later". Capture it elsewhere; don't let it crowd the brief.

## People who matter

Names + a sentence each. The handful of people the agent should know on sight.

- **[Name]** — [relationship, why they matter, anything important to remember]
- **[Name]** — [...]
