# Now — running cockpit

The live state of the day. The agent updates this during normal conversation; the `morning-brief` skill reads here first. Keep it short — this is a cockpit, not a journal. Absolute dates only.

Last updated: [YYYY-MM-DD]

## Today

The 1–3 real outcomes for today. Not a calendar dump — what actually has to move.

- [ ] [outcome / priority]
- [ ] [outcome / priority]

## Waiting

Things you owe someone, or someone owes you. Each line: who, what, since when.

- [person] — [what] — since [YYYY-MM-DD]

## Delegated

Work handed to someone else that you're tracking but not doing.

- [person / who] — [what] — handed off [YYYY-MM-DD]

## Follow-ups

Near-term follow-ups with a date attached. If a date is named and reminder capability is available, the agent can also set a one-time reminder.

- [YYYY-MM-DD] — [follow-up]

## Notes

Anything that changed and matters but doesn't fit above — a contact update, a context shift. Keep it brief; promote to a decision or a goal if it's durable.

- [note]
