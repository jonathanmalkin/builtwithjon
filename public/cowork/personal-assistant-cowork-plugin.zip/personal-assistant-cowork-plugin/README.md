# Personal Assistant Cowork Plugin

This plugin packages the personal assistant skills as one installable bundle for
Claude Cowork / Claude Code plugin surfaces.

## Included Skills

- `setup` - the single setup path, end to end: interviews the user and writes
  `CLAUDE.md` / `USER.md` / `now.md` / `decision-log.md`, establishes the
  flattened structure, checks connectors and discovers their tool names, deploys
  the live Daily Brief artifact, and creates the weekday morning scheduled task.
  Re-run it to refresh the profile.
- `morning-brief` - reads profile, agenda, calendar, and inbox signals.
- `email-triage` - classifies recent mail and creates Gmail drafts only.
- `meeting-prep` - prepares for upcoming meetings and contact context.
- `capture` - records decisions, follow-ups, meetings, contact notes, durable
  user facts, and lasting preferences.
- `skill-builder` - creates or updates assistant skills with approval.

## Assets

- `assets/daily-brief.template.html` - the live Daily Brief artifact template
  (Sunsama theme, soft purple gradient). The `setup` skill fills its four deploy
  tokens (`__USER_NAME__`, `__TZ__`, `__CAL_TOOL__`, `__DRAFTS_TOOL__`), runs
  `node --check` on its script, and deploys it with `create_artifact`. It reads
  only Google Calendar `list_events` and Gmail `list_drafts`, does no AI
  inference, and renders with per-call timeouts.

## State Layout

State files live in the **Project root** - there is no `workspace/` folder:

- Root files: `CLAUDE.md`, `USER.md`, `now.md`, `decision-log.md`, `voice.md`
- Root folders: `meetings/`, `contacts/`, `outputs/`

## Cowork Setup

The fast path is the `setup` skill - install the plugin, run it, answer a few
questions, done.

1. Create a Cowork Project named after the assistant (for example `Margaret` or
   `Pam`). The folder can live anywhere.
2. Install the packaged zip from the follow-up pack:
   `personal-assistant-cowork-plugin.zip`.
   - In Claude Desktop, open Cowork.
   - Open Customize, then Plugins (Personal Plugins).
   - Select the upload option and choose the zip file.
   - Open the installed plugin and confirm the skills appear, including `setup`.
3. Connect one Gmail and one Google Calendar if they are not already connected.
4. Start a task in the Project and ask:

```text
Run the setup skill.
```

`setup` interviews the user, writes the profile and `CLAUDE.md` (and shows it to
paste into Project Instructions as a fallback), discovers the connector tool
names, deploys the Daily Brief artifact, and creates the weekday morning
scheduled task (8:00 AM by default, on the user's default model). The user then
runs that scheduled task once from the Scheduled menu and grants the permissions
needed for future daily runs.

The morning text is optional: if the **Read and Send iMessages** connector is
configured, `setup` asks which phone number or email associated with iMessage to
text and sends the brief there one-way. If it is not configured, `setup` skips
that question entirely.

If the slash menu is available, type `/` or click `+` and choose the installed
`setup` skill from this plugin.

## Channels

- **Dispatch** is the only inbound phone path.
- **iMessage** is one-way, outbound-to-the-user's-own configured destination
  notifications only (the optional morning brief text). The assistant does not
  read inbound texts or act on them.
- **Telegram** is an advanced/custom channel, not the basic setup path.

## Validation

This plugin should pass:

```text
claude plugin validate personal-assistant-cowork-plugin
```

## Output Contract

Human-facing reports should be written as both HTML and plain text under
`outputs/`. Markdown remains acceptable for Claude-facing state files such as
`CLAUDE.md`, `USER.md`, `now.md`, and
`decision-log.md`.

See `references/report-output-contract.md`.
