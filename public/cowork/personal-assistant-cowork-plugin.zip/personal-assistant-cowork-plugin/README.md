# Personal Assistant Cowork Plugin

This plugin packages the personal assistant skills as one installable bundle for
Claude Cowork / Claude Code plugin surfaces.

## Included Skills

- `interview` - creates `CLAUDE.md`, `USER.md`, and agenda files.
- `morning-brief` - reads profile, agenda, calendar, and inbox signals.
- `email-triage` - classifies recent mail and creates Gmail drafts only.
- `meeting-prep` - prepares for upcoming meetings and contact context.
- `capture` - records decisions, follow-ups, meetings, and contact notes.
- `teach` - captures lasting preferences with explicit approval.
- `skill-builder` - creates or updates assistant skills with approval.
- `deep-voice-profile` - runs the long-form voice profile workflow.

## Cowork Setup

1. Create a Cowork Project named after the assistant (for example `Margaret` or `Pam`).
2. Add the participant's `CLAUDE.md`, `USER.md`, and `workspace/Agenda/` files.
3. Paste `references/cowork-project-instructions.md` into Project instructions.
4. Install the packaged zip from the follow-up pack:
   `personal-assistant-cowork-plugin.zip`.
   - In Claude Desktop, open Cowork.
   - Open Customize, then Plugins.
   - Select the upload option and choose the zip file.
   - Open the installed plugin and confirm the skills appear.
5. Start a new task in the Project and ask:

```text
Run the interview skill and set up my personal assistant.
```

If the slash menu is available, type `/` or click `+` and choose the installed
`interview` skill from this plugin.

## Validation

This plugin should pass:

```text
claude plugin validate personal-assistant-cowork-plugin
```

## Output Contract

Human-facing reports should be written as both HTML and plain text under
`outputs/`. Markdown remains acceptable for Claude-facing state files such as
`CLAUDE.md`, `USER.md`, `workspace/Agenda/now.md`, and
`workspace/Agenda/decision-log.md`.

See `references/report-output-contract.md`.
