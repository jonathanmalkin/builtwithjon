#!/usr/bin/env bash
# =============================================================================
# send-telegram.sh — send one text message to YOUR OWN Telegram, nothing else.
#
# WHAT THIS SCRIPT DOES, IN FULL (safe to read before running):
#   1. Reads one file in THIS folder: .env (your bot token + your chat id).
#      It reads nothing else on your computer.
#   2. Makes ONE https request to the official Telegram API
#      (https://api.telegram.org) to send the message text to your chat.
#   3. Prints whether it worked.
#
# WHAT IT DOES NOT DO:
#   - It does not delete, move, or modify any of your files.
#   - It does not use sudo, eval, or run any code from the message text.
#   - It does not contact any server other than api.telegram.org.
#   - It does not read your contacts, keys, browser, or anything outside
#     this folder.
#
# You must provide your own bot token + chat id via setup-telegram.sh. Without
# them this script does nothing but print a "not configured" notice and exit.
#
# Usage:
#   telegram/send-telegram.sh --file /path/to/brief.txt
#   telegram/send-telegram.sh --text "literal message"
#   echo "message" | telegram/send-telegram.sh -
#
# Exit codes: 0 ok | 1 usage | 2 not configured | 3 API call failed | 4 bad response | 5 curl missing
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"

# --- dependency check ---
if ! command -v curl >/dev/null 2>&1; then
  echo "Delivery: Telegram skipped (curl not installed on this machine)." >&2
  exit 5
fi

# --- load config (skip cleanly if attendee hasn't set up Telegram) ---
if [[ ! -f "$ENV_FILE" ]]; then
  echo "Delivery: Telegram skipped (not configured — run setup-telegram.sh first)." >&2
  exit 2
fi
# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

if [[ -z "${TELEGRAM_BOT_TOKEN:-}" ]]; then
  echo "Delivery: Telegram skipped (TELEGRAM_BOT_TOKEN not set in $ENV_FILE)." >&2
  exit 2
fi

CHAT_ID="${TELEGRAM_CHAT_ID:-}"
if [[ -z "$CHAT_ID" ]]; then
  echo "Delivery: Telegram skipped (TELEGRAM_CHAT_ID not set in $ENV_FILE — run setup-telegram.sh)." >&2
  exit 2
fi

# --- read message body ---
if [[ "${1:-}" == "--file" && -n "${2:-}" ]]; then
  BODY="$(cat "$2")"
elif [[ "${1:-}" == "--text" && -n "${2:-}" ]]; then
  BODY="$2"
elif [[ "${1:-}" == "-" ]]; then
  BODY="$(cat -)"
else
  echo "Usage: $0 --file <path> | --text \"msg\" | -" >&2
  exit 1
fi

if [[ -z "${BODY//[[:space:]]/}" ]]; then
  echo "ERROR: empty message body" >&2
  exit 1
fi

# --- send (plain text; no parse_mode so markdown in the brief won't break the API) ---
RESP="$(curl -fsS -X POST \
  "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
  --data-urlencode "chat_id=${CHAT_ID}" \
  --data-urlencode "text=${BODY}" \
  --data-urlencode "disable_web_page_preview=true" 2>/dev/null)" || {
    echo "ERROR: Telegram API call failed" >&2
    exit 3
  }

if echo "$RESP" | grep -q '"ok":true'; then
  echo "Delivery: sent via Telegram (chat ${CHAT_ID})."
  exit 0
else
  echo "ERROR: Telegram API returned failure: $RESP" >&2
  exit 4
fi
