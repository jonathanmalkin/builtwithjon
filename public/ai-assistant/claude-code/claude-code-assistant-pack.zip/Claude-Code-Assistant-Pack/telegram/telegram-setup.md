# Telegram setup — get your morning brief on your phone

Optional, and the best option for Android (where iMessage can't reach you). This
sends your morning brief to your phone through a free Telegram bot you create.

**You do 3 quick things by hand. Claude does the rest.**

---

## The only steps that need you (do these on your phone, ~2 min)

1. Open the **Telegram** app and search for **@BotFather** (official, blue
   checkmark). Open it.
2. Send `/newbot`. When asked, give it any **name**, then a **username ending in
   `bot`** (add numbers if it's taken). BotFather replies with a **token** that
   looks like `123456789:AAH...` — copy it.
3. Tap your new bot and send it any message (e.g. `hi`).

That's the entire manual part.

---

## Then hand it to Claude

In a chat in this project, paste this prompt and replace the token with yours:

```
Set up Telegram delivery for my morning brief. My bot token is: <PASTE-YOUR-TOKEN-HERE>

Run telegram/setup-telegram.sh with that token to save it and find my
chat id, then send a test message to confirm it reaches my phone. Tell me if it
worked, and if the chat id isn't found, tell me to message my bot again.
```

Claude will run the setup script, save your token + chat id, send a test, and
confirm. If you'd rather do it yourself, the manual equivalent is one command:
`telegram/setup-telegram.sh <YOUR-TOKEN>` then
`telegram/send-telegram.sh --text "test"`.

---

## After that, nothing

Your morning brief delivers to Telegram automatically on every run, including
your scheduled routine. Permission is already handled by the pack's
`.claude/settings.json`, so a scheduled run never stops to ask.

**Safe to run:** the scripts only read your config in this folder and make one
call to the official Telegram API — nothing else. Your token is saved to
`telegram/.env`, which is git-ignored, so it's never shared. Not set up?
The brief just skips Telegram quietly and still runs everything else.
