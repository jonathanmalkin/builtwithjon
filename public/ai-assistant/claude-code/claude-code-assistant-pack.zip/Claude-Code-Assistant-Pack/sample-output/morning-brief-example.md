# Morning Brief — Wednesday, May 21

*Calendar ok · Gmail ok · profile current*

## Today

- 9:00 AM — Daily agenda block (solo, no meeting)
- 11:30 AM — Coffee with Sarah Chen (prospective hire) — Cafe Medici
- 2:00 PM — Q2 roadmap review with engineering — Zoom
- 6:30 PM — ACE meetup, "Designing AI-Powered Operations" — virtual

## Meeting prep

- 11:30 AM — Sarah Chen — Prepped (see `2026-05-21 - Sarah Chen.md` in Project). Walk in knowing: she left her last role specifically because of the ops/strategy split — your pitch about the hybrid role lands here if you lead with it.
- 2:00 PM — Q2 roadmap — Not prepped. Engineering wants a call on the data-pipeline rewrite vs. the customer-portal upgrade. Decide before the meeting which one you're advocating for.

## Threads needing attention

- "Re: contract draft" from David Lim — He sent revised terms Monday, you haven't responded.
- "Workshop logistics" from Chrissy — Needs a room booking confirmation by EOD.
- "Quick question" from Roger — Open since last Thursday, low urgency but visible.

## First move

Reply to David Lim's contract revisions. 15 minutes. Anything else slides until that's off your plate — and it moves the "close the Q3 partnership" goal, so it's the right first move twice over.

## Goal progress

- **Close the Q3 partnership deal** — Moving. The David Lim contract thread is the live edge; clearing his revisions today is real progress. MSA still parked with legal.
- **Hire an ops lead** — Moving. 11:30 coffee with Sarah Chen is a genuine candidate conversation — first real movement this week.
- **Ship the customer portal v2** — Stalled. Nothing on today's calendar touches it, and no portal email in 4 days. If the 2 PM roadmap review doesn't protect engineering time for it, this goal slips another week.

## Waiting on others

- Legal on the MSA redline (since May 16, 5 days)
- Anna on the LinkedIn intro to the platform partnerships lead (since May 19)

## Watch-outs

- Q2 roadmap meeting collides with your "no major decisions without a 2-hour buffer" rule — you have 30 minutes before it. Decide the data-pipeline question this morning, not in the meeting.
- Profile says "protect Wednesday afternoons for deep work" — today has the 2 PM block but the 6:30 PM event will eat the evening. One or the other.
- Approval boundary: agent drafts, you send. No outbound action today without your explicit go-ahead.
