# Report Output Contract

Use this contract for human-facing reports from the personal assistant:

- Morning brief.
- Email triage.

Meeting prep has its own packet output contract: the meeting report lives in
`meetings/` as Markdown and HTML, with linked contact/company files. Do not
write meeting-prep reports under `outputs/`.

Claude-facing state files may stay in Markdown. Morning brief and email triage
reports should be HTML and plain text.

## File Names

Create an `outputs/` folder if it does not exist.

Use these patterns:

- `outputs/YYYY-MM-DD-morning-brief.html`
- `outputs/YYYY-MM-DD-morning-brief.txt`
- `outputs/YYYY-MM-DD-email-triage.html`
- `outputs/YYYY-MM-DD-email-triage.txt`

Meeting prep:

- `meetings/YYYY-MM-DD - [Meeting Title].md`
- `meetings/YYYY-MM-DD - [Meeting Title].html`

Use the user's local calendar date for `YYYY-MM-DD`.

## HTML Requirements

- Use a complete HTML document, not a fragment.
- Use light mode only.
- Use system fonts.
- Use warm paper background `#fbf6ec`, porcelain panels `#fffdf8`, ink text
  `#1f1713`, muted text `#5e5047`, borders `#e5d7c3`, and blue accents
  `#3b6e8f`.
- Keep line length readable.
- Use real headings and lists.
- Do not use decorative gradients, dark mode, or tiny text.
- Add a small freshness/status line when data access was degraded.

## Plain Text Requirements

- No Markdown formatting tricks required.
- Use short section headings.
- Use plain bullets with `-`.
- Keep lines easy to scan on a phone.
- Use AM/PM times.
- Include "Nothing was sent" when email drafts were created.

## Chat Response

After writing files, reply with:

- A short summary.
- Links or file paths to the created outputs.
- Draft/send status for email triage.
- Data freshness or connector gaps.
