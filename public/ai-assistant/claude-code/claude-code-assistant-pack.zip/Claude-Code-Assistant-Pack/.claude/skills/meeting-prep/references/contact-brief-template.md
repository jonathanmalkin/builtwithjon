# [Person's Name]

**Brief generated:** [YYYY-MM-DD]
**Meetings in this prep window:** [meeting title, date/time; include every discovered meeting this person appears in]
**Linked companies / orgs:** [linked company/org brief(s), or "none identified / not relevant"]
**Connector status this run:** [web search / Gmail / Calendar / Drive — available, available but needs permission, or not exposed in this session]
**Source coverage:** owned context [count] · public professional footprint [count] · public social/content signals [count]

## Who they are

[One sentence: role, company, and why they're in the user's meeting window. Include an inline source mention, e.g. "per [Company bio](https://example.com/team)."]

## What they care about

- [Theme or value, with a one-line example and inline clickable source mention.]
- [...]

## Recent signal — last 30 to 90 days

- [What they've been writing, shipping, talking about. Date or rough timeframe + inline clickable source mention.]
- [...]

## Prior context with you

*Skip this section entirely only if Gmail and Calendar were not exposed after discovery, or permission was declined.*

- **Last email thread:** [subject + date + unresolved bit; mention Gmail and stable thread details if no direct link is available]
- **Last meeting:** [date + what it was + what was agreed; mention Calendar event title/date or link a local meeting file]
- **Open threads:** [anything left hanging, with inline source mention]

## The one thing you'd miss

[The non-obvious detail. The thing that would surprise you ten minutes into the meeting. If nothing surfaced, say so directly rather than padding.]

## Questions to ask

Things to actually ask when this person is in the room:

- [question]
- [question]

## Sources

Every source used in the brief, grouped by lane:

- **Owned context:** [local file link, Gmail thread subject/date, Calendar event title/date, Drive/doc link]
- **Public professional footprint:** [clickable web source]
- **Public social/content signals:** [clickable public profile/post/source]

## Gaps / unavailable

[If LinkedIn, a connector, or a specific source was unavailable, say so here. Not fabricating around a gap is more useful than a complete-looking brief.]
