# [Company / Organization / Project Name]

**Brief generated:** [YYYY-MM-DD]
**Meetings in this prep window:** [meeting title, date/time; include every discovered meeting tied to this org]
**Connector status this run:** [web search / Gmail / Calendar / Drive — available, available but needs permission, or not exposed in this session]
**Confidence:** [high / medium / low] — [why]

## What it is

[One tight sentence on the org, product, community, project, or venue. Include an inline source mention, e.g. "per [official site](https://example.com)."]

## Linked people

- [Person name](../contacts/[Person Name].md) — [role / relationship / confidence]
- [...]

## Why it matters now

[Why this org belongs in the meeting packet right now. Tie it to the scheduled meeting, current project, workshop, opportunity, or relationship context.]

## Likely workflows / pain points

Only include sourced or clearly labeled inference.

- [workflow or pain point] — [source or "inference from meeting context"]
- [...]

## How the user can help

Concrete offers only. Avoid generic "AI consulting."

- [specific workflow, workshop, teardown, implementation, intro, or resource]
- [...]

## Questions to ask

- [org-specific question]
- [org-specific question]

## Risks / approval boundaries

- [what not to promise, send, schedule, quote, or publish]
- Approval boundary: no outbound message, calendar change, proposal, quote, payment, referral term, public post, or external commitment without explicit confirmation.

## Sources

Every source used in the brief, grouped by lane:

- **Owned context:** [local file link, Gmail subject/date, Calendar event title/date, Drive/doc link]
- **Public professional footprint:** [clickable web source]
- **Public social/content signals:** [clickable public profile/post/source]

## Gaps / unavailable

[If the company identity, official site, role, connector, or source is weak/unavailable, say so here. A useful low-confidence brief is better than a confident fake one.]
