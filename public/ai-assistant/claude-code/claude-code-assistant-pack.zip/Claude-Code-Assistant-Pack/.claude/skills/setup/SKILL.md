---
name: setup
description: Use when the user invokes /setup or asks to set up, install, configure, get started with, or refresh their personal assistant in Claude Code. The single setup path, end to end - it interviews the user, writes their profile to the project root, connects and discovers Gmail/Google Calendar, and creates the weekday morning scheduled task (Routine) that writes a file-based Daily Brief. Re-running it later refreshes the profile.
---

# Setup

Take the user from "pack opened as a Claude Code project" to "fully running" in
one pass. Do the work yourself; only ask the user what you genuinely need. Keep
them posted with a short line per step.

By the end the project root holds `CLAUDE.md`, `USER.md`, `now.md`,
`decision-log.md` (everything flat in the root, no `workspace/` folder), and the
weekday morning scheduled task is created (8:00 AM by default). The task writes a
file-based Daily Brief into `outputs/` each weekday. The user runs the task once
from the Routines menu after setup so Claude can collect standing permission for
daily runs.

**This is the Claude Code path.** The assistant lives in plain local files you
can open and inspect. There is no live Cowork artifact here - the Daily Brief is
an HTML + text file in `outputs/` that the scheduled task refreshes. That file
transparency is the point of the Claude Code version.

**Boundary (installed, never relaxed):** read freely, draft freely, write local
project files, and (if the user opted in) text the user *their own* brief. Never
send email to others, post, delete, buy, or change calendar events without the
user's explicit approval of the exact action. Gmail **drafts** and the user's
**own** phone notification are the only outbound writes the morning task makes.

For phone use there are two separate levels, and they must not be conflated:

- **One-way notification (what this skill wires):** the morning task texts the
  user *their own* brief via the **Read and Send iMessages** connector or the
  bundled Telegram send script (`telegram/send-telegram.sh`). Outbound to the
  user only; never reads inbound texts or takes commands.
- **Two-way Channels (advanced, opt-in, the user sets it up, not this skill):**
  Claude Code's native Channels feature lets the user text the session and have
  it act. If the user asks about it, point them to the "two-way Channels" step on
  the setup page / the official docs; do not configure it from this skill. Even
  with Channels on, the action-approval gate above still holds: inbound requests
  are allowed, but sending, posting, deleting, buying, and calendar changes still
  wait for explicit approval.

## Step 1 - Detect, then ask only what's left

Check the environment first, ask only what's left. The core interview is two
questions (name, goals); fold the one-line notify offer into the same opening
message when a phone channel isn't already set up.

- **Timezone:** detect from the locale/environment; default the morning run to
  **8:00 AM** weekdays there. Only ask if you truly can't detect it.
- **Phone notification (optional, one-way):** check whether a delivery path
  exists - the **Read and Send iMessages** connector (alias `iMessage`,
  `Messages`) or the bundled Telegram script (`telegram/send-telegram.sh`,
  configured only if the user ran its setup, token in `telegram/.env`).
  - **If one is present:** ask for the destination (their own number / Apple ID
    email for iMessage; nothing more for Telegram once configured) and wire it
    into the morning task.
  - **If neither is set up:** do not silently skip. Ask the user, in one short
    line, whether they want to turn on a one-way phone brief now, and offer
    **iMessage**, **Telegram**, **both**, or **skip**. If they pick one or both,
    state plainly **what they do** and **what you do**, then act:
    - **iMessage** (Mac + iPhone): *They do:* add the **Read and Send iMessages**
      connector under Customize -> Connectors, and give you the number or Apple ID
      email to text. *You do:* confirm the connector is reachable and bake that
      destination into the morning task. If the connector isn't added yet, say so
      and continue once they add it (or move on and note they can add it later).
    - **Telegram** (any phone, incl. Android): *They do:* create a bot in
      **@BotFather** (`/newbot`) and paste you the token. *You do:* run
      `telegram/setup-telegram.sh <token>` to save it and find their chat id, send
      a test, confirm it arrived, and wire the script into the morning task. If
      the chat id isn't found, tell them to message their bot once and retry.
    - **Skip:** fine - the brief still lands in `outputs/`; note they can add a
      channel later by re-running `setup`.
  - This is **notification only** (outbound, their own brief). If the user instead
    wants to *text the assistant and have it act*, that is the separate two-way
    **Channels** feature: point them to the setup page's "two-way Channels" step
    and the docs, and do not configure it here.

Then ask, in one short message:

1. **Assistant name** - suggest the folder name if you can see it.
2. **Your top 2-3 goals for the next 90 days**, and the project serving each.
3. *(Only if no phone channel is set up)* whether they want a one-way phone
   brief: **iMessage**, **Telegram**, **both**, or **skip** (per the notify
   handling above).

That's the whole interview - keep it that short. Don't ask for tone or operating
overrides (the `CLAUDE.md` defaults stand), and don't run a long profile
interview. Everything else (people, week shape, deeper goal detail) the assistant
fills in over time via `capture`, or the user can re-run `setup`. Confirm name,
timezone, 8:00 AM, goals, and notify choice in one line, then go.

## Step 2 - Write the profile files

Fill the `references/` templates from what you have and write to the **project
root**, leaving bracketed prompts (`[no people captured yet]`) where the user
gave nothing - never fabricate:

- `CLAUDE.md` from `references/_CLAUDE.md` (replace the name; keep shipped
  tone/behavior defaults as-is). This is the durable operating contract Claude
  Code loads automatically from the project root.
- `USER.md` from `references/_USER.md` (identity + the goals; bracket the rest).
- `now.md` from `references/now-file-template.md`;
  `decision-log.md` from `references/decision-log-template.md`.

These four files in the project root are the whole memory layer. Claude Code
reads `CLAUDE.md` automatically at the start of every session in this folder, so
once written the assistant knows itself on the next chat.

## Step 3 - Connect and discover Gmail and Google Calendar

**Discover the connector tool names.** Skills call connectors by name; on some
runtimes those names embed a per-user server id
(`mcp__<id>__list_events`, `mcp__<id>__list_drafts`). Discover them per the
`CLAUDE.md` "Connector and delivery discovery" procedure (active list -> deferred
list + aliases `Gmail`/`mail`, `Google Calendar`/`gcal` -> load schema ->
harmless probe). Confirm the accounts ("Found Gmail name@... and Calendar X - use
these?") so you don't wire up the wrong inbox. If one is missing, walk them
through Customize -> Connectors -> Browse connectors -> Connect, then resume;
mention Workspace-admin enablement only on a permission error.

Approve the minimum permissions the user is comfortable with: Calendar and Gmail
read access cover the core; Gmail draft creation covers email triage.

## Step 4 - Create the weekday scheduled task (Routine)

This is the automation that runs the morning brief on its own. Claude Code
Desktop supports both creating it for the user and falling back to manual steps.

**Try to create it programmatically first.** If the `create_scheduled_task` MCP
tool is available in this session, use it:

- taskId / name: `daily-brief-refresh`
- schedule: weekdays at the chosen time (default 8:00 AM local). If the tool
  takes cron, use `0 8 * * 1-5` (local time - no UTC conversion). If it takes a
  preset, choose **Weekdays** at 8:00 AM.
- working folder: this project folder (so the run can read `CLAUDE.md`, `USER.md`,
  `now.md`, and the skills, and write to `outputs/`).
- model: the user's default.

You can also create it conversationally if that is the available path: in a
Desktop session, "set up a local scheduled task named daily-brief-refresh that
runs every weekday at 8am in this folder" creates it. Either way, keep the task
prompt **fully self-contained** - the run has no memory of this chat. Bake in the
assistant name, timezone, the notify choice + destination, and the exact paths it
reads and writes (`now.md`, `USER.md`, `voice.md`, `outputs/`, `meetings/`,
`contacts/`, `companies/` in the project root). The prompt should, in order:

1. Run `meeting-prep` for today + tomorrow, creating linked Markdown and HTML
   packets in `meetings/`/`contacts/`/`companies/`. The meeting report lives only
   in `meetings/`, not `outputs/`.
2. Run `email-triage` on the last 48h - **create Gmail drafts only, never send**.
   Use `voice.md` for tone **if it exists; if not, proceed without it**.
3. Run `morning-brief` to compose a 48-hour brief from `now.md`, `USER.md`, the
   calendar, and the triage, and write `outputs/YYYY-MM-DD-daily-brief.html` and
   `.txt`. This file IS the Daily Brief on the Claude Code path.
4. If a phone channel is on, send the brief to the user's **own** configured
   iMessage number/email or via the bundled Telegram script - to the user only.
5. Ask nothing during the run; note any gaps.

**If `create_scheduled_task` is not available** (older or limited Claude Code),
do not stall. Tell the user to create it by hand and give the exact steps:

> Open **Routines** in the Claude Code sidebar -> **New routine** -> **Local**.
> Name it `daily-brief-refresh`, set the schedule to **Weekdays** at **8:00 AM**,
> set the working folder to this project folder, and paste the task prompt below.

Then print the same self-contained task prompt in a copy block so they can paste
it. A `SKILL.md` for the task also lives on disk at
`~/.claude/scheduled-tasks/daily-brief-refresh/SKILL.md` once created, if they
want to edit it later.

Local scheduled tasks run only while Claude Code Desktop is open and the computer
is awake. Tell the user they can enable **Keep computer awake** in Settings if
they want it to fire reliably at 8:00 AM.

## Step 5 - First run and standing permission

Do **not** run the task yourself during setup. Tell the user to run it once from
the Routines menu so Claude can collect standing permission for daily runs:

> Open **Routines**, select **daily-brief-refresh**, click **Run now**, open the
> session that starts, and approve every permission with **"always allow"** so
> future runs do not stall while you are away.

The pack ships a `.claude/settings.json` that pre-authorizes the delivery tools
(the Telegram script and the iMessage send tool), so those will not prompt; the
connector reads still need the one-time "always allow."

## Done

Recap in a few lines: assistant name and files written to the project root;
connectors live; the weekday `daily-brief-refresh` task is created (or the manual
steps were given); the task writes a file-based Daily Brief to `outputs/` each
weekday at [time]; tell the user to run it once from Routines and approve
permissions; re-run `setup` anytime to refresh; and the boundary - read, draft,
notify-myself only.
