---
name: capture
description: >-
  Use when the user says something changed, asks the agent to remember, log,
  capture, note, track, or follow up on a decision, priority shift, meeting
  outcome, person/contact update, waiting item, delegated item, completed item,
  reminder, post-meeting note, durable user fact, or lasting preference about
  how the assistant should behave. Keeps the Project's local agenda, meeting
  records, contact records, company/org records, profile files, and operating
  preferences current without taking external action.
---

# Capture

Keep the user's local assistant state current as normal conversation unfolds.
Capture is not a journal and not a transcript digest. It records the smallest
useful update in the right local file so tomorrow's brief, future meeting prep,
later contact/company context, and future assistant behavior are better.

Use this skill even when the user does not type `/capture`. If they say
something changed or something should stick, capture it before replying.

## Two Lanes

### Work state

Use this lane for updates about the user's world:

- decisions
- priority changes
- waiting items and follow-ups
- delegated work
- meeting outcomes or post-meeting notes
- person/contact updates
- company/org updates
- completed items
- reminders

Write these into the Project root state files (`now.md`, `decision-log.md`),
`meetings/`, `contacts/`, or `companies/`.

### Preferences and durable profile facts

Use this lane when the user states something that should change a future,
unrelated chat:

- "from now on", "going forward", "always", "never", "by default"
- "stop doing X", "quit X-ing", "you keep doing X"
- "I prefer", "I like it when you", "I hate when you", "don't ever"
- "remember I'm based in", "my co-founder is", "I work in X so assume Y"

Write assistant behavior preferences into `CLAUDE.md`. Write durable facts
about the user into `USER.md`.

Do not capture one-off edits to the current artifact, such as "make this
paragraph tighter" or "redo that as a list." Those are task instructions, not
preferences. If unsure whether something generalizes, ask one short question:
*"One-off, or should I make this the default from now on?"*

## Files

- `now.md` — current cockpit: today, waiting, delegated,
  follow-ups, near-term notes.
- `decision-log.md` — durable dated decisions.
- `meetings/` — meeting prep and post-meeting outcome notes.
- `contacts/` — person/contact briefs and relationship context.
- `companies/` — company, organization, project, community, product, and venue
  briefs connected to meetings and contacts.
- `CLAUDE.md` — assistant operating rules, style preferences, approval
  boundary, and profile-level overrides.
- `USER.md` — durable user identity, goals, people, and context.

Create folders or missing agenda files when needed. If an agenda template exists
in the `setup` skill's `references/` folder, use it; otherwise create a
minimal Markdown file.

Profile edits are propose-then-write. Because they change the assistant's own
operating context, show the exact line before saving and wait for confirmation.

## Work State Routing

### Agenda

Update `now.md` for current work:

- **Priority change:** edit the relevant Today or priority line; remove or mark
  stale contradictions.
- **Waiting / follow-up:** add who, what, and the clearest date it started or
  is due.
- **Delegated work:** add who owns it, what they own, and when it was handed
  off.
- **Completed item:** mark it done with a one-line outcome instead of leaving
  it open.
- **Near-term note:** add only if it affects the next brief or next action.

Use absolute dates like `2026-05-28` inside files, never "today" or
"yesterday."

### Decisions

Append durable decisions to `decision-log.md` with:

- date
- decision
- reason or context
- any follow-up if needed

Also update `now.md` if the decision changes current work.

### Meetings

For meeting outcomes, post-meeting notes, or prep-relevant corrections:

1. Create `meetings/` if needed.
2. Find an existing meeting file by date, title, person, or distinctive phrase.
3. If none exists, create `meetings/YYYY-MM-DD - [Meeting Title or Person].md`.
4. Add a dated section such as:

```md
## Outcome — YYYY-MM-DD

- Source: user-supplied conversation capture
- What happened:
- Commitments / next steps:
- Open questions:
- Follow-up state:
```

Keep private readout notes separate from any outbound draft. Do not imply
commitments the user did not make.

### Post-meeting conversion

When the user gives meeting notes after a call, coffee, workshop, demo, event,
or appointment, convert the existing prep packet into outcome state instead of
only appending a note.

1. Identify the packet:
   - meeting file in `meetings/`
   - contact file(s) in `contacts/`
   - company/org file(s) in `companies/`
   - any linked HTML copies of those files
2. If the packet files do not exist, create the minimum useful set:
   - `meetings/YYYY-MM-DD - [Meeting Title or Person].md`
   - `contacts/[Person Name].md` for known people
   - `companies/[Company or Org Name].md` when the org context matters
3. Update the meeting file first. Change stale `upcoming`, `prep`, or
   `before the meeting` language to completed/outcome language when the meeting
   has happened. Add:

```md
## Post-meeting outcome — YYYY-MM-DD

- Source: user-supplied post-meeting notes
- Readout:
- What they seemed to want:
- What the user offered or explained:
- Ideas discussed:
- Commitments / non-commitments:
- Follow-up assets:
- Next action:
- Approval state:
```

4. Update each contact file with a concise dated relationship note. Link back to
   the meeting file. Do not paste the full meeting outcome into every contact.
5. Update each company/org file with the relationship-relevant business,
   workflow, event, product, community, or opportunity signal. Link back to the
   meeting file and contact files.
6. If the meeting opens a reusable opportunity, workshop lane, report, source
   map, or research question, record it as a follow-up in `now.md` unless the
   user says to park it.
7. Regenerate or update linked HTML copies for every Markdown file you changed
   when the packet uses HTML copies. Keep the HTML readable, light-mode, and
   link-connected. If you cannot update HTML in the current session, say which
   Markdown changed and which HTML copy is stale.
8. Separate internal notes from outbound drafts. A follow-up draft can be saved
   only as a draft artifact; sending, scheduling, quoting, proposing, or
   promising still requires exact user approval.

If the notes are from an AI meeting summary rather than the user's own recap,
mark the source as `AI notes supplied by user; transcript not verified` and do
not launder uncertain claims into verified fact.

### Contacts

For person/contact updates:

1. Create `contacts/` if needed.
2. Find an existing contact file by name or obvious alias.
3. If none exists, create `contacts/[Person Name].md`.
4. Add or update a concise dated note:

```md
## Notes

- YYYY-MM-DD — [relationship context, preference, open loop, or useful fact]
```

If the identity is uncertain, create an unresolved contact file such as
`contacts/unknown-[short-description].md` rather than merging into a
known person without evidence.

Also update `now.md` when the contact update creates a current follow-up,
waiting item, or meeting prep need.

### Companies / orgs

For company, organization, project, product, community, or venue updates:

1. Create `companies/` if needed.
2. Find an existing company/org file by name, domain, event title, product name,
   or linked meeting/contact file.
3. If none exists and the org context matters, create
   `companies/[Company or Org Name].md`.
4. Add or update a concise dated note:

```md
## Notes

- YYYY-MM-DD — [relationship, workflow, event, opportunity, risk, or useful fact]
```

Keep company/org notes grounded. If the org identity is uncertain, create a
low-confidence file such as `companies/unknown-[domain-or-event].md` and name
the missing evidence.

### Reminders

If the user names a date or time for a reminder, check both the active tool list
and any tools that load on demand before deciding reminder delivery is
unavailable. Search active and deferred capabilities for reminder/task tools,
calendar reminder tools, and any approved personal delivery destination. The
reminder prompt must be self-contained, surface the reminder only, and take no
external action toward other people.

If reminder creation is unavailable, log the follow-up in `now.md` and say it
was not scheduled.

## Preference And Profile Routing

### CLAUDE.md — how the assistant behaves

Most preferences land here. Match the preference to the closest existing
section:

- **Tone, answer shape, length, when-I'm-wrong, uncertainty** →
  `## How to talk to me`
- **Things to stop doing — emojis, flattery, hedging, re-explaining, padding**
  → `## What to avoid`
- **Working style that isn't tone or avoidance** — when to interrupt,
  brainstorm vs. execute, ask-first vs. do-and-flag → if a
  `## How I work with you — overrides` block exists, add there; if not, create
  that block directly above the `## Read / Draft / Approve` boundary.

### USER.md — durable facts about the user

If the "preference" is really a fact about who the user is or their context, it
belongs in `USER.md`, not `CLAUDE.md`:

- Identity, role, location → `## Identity`
- A person who should be known on sight → `## People who matter`
- A goal or project shift → `## Goals — next 90 days` (but a substantive goal
  change is better handled by re-running `setup`)
- Domain shorthand / vocabulary → if the template has a domain section use it;
  otherwise note it under `## Identity` as a one-liner.

When in doubt: does this describe the user, or instruct the assistant? User →
`USER.md`. Assistant → `CLAUDE.md`.

## How To Write Profile Edits

1. **Restate the preference as one rule.** Compress what the user said into a
   single imperative line. Example: user says "I really don't need you
   summarizing everything you just did at the end, I can read it" → rule:
   *"Don't append a summary of what you just did at the end of a response."*
2. **Pick the destination file and section.**
3. **Show the user the exact edit before writing:**

   > I'll add this to `CLAUDE.md` under **What to avoid**:
   > - *Don't append a summary of what you just did at the end of a response. (override — added 2026-05-28)*
   >
   > Good as-is?

4. **On confirmation, write it.** On a tweak, adjust and write. If the user says
   it was a one-off after all, do not write anything.
5. **Confirm briefly:** `Learned. Added to CLAUDE.md → What to avoid. It'll
   apply from your next chat in this Project.`

Remind the user once, the first time you write a profile edit in a session, that
profile changes load on the next chat in the Project. The current chat already
has the old version in context.

Write profile edits as one line, imperative, matching the surrounding file's
voice. Tag every change as an override with a date so the user can see what
changed from the shipped defaults: `(override — added YYYY-MM-DD)`.

Reconcile, do not pile up. Before adding, scan the target section for a default
or earlier override that this contradicts. If the new preference replaces an old
line, edit that line and note it as `(override — revised YYYY-MM-DD)` rather
than leaving two rules that fight. If it narrows a default, keep the default and
add the exception beneath it.

If the user says "stop doing that / never mind / undo that preference / go back
to default", find the matching override line and remove it or restore the
shipped default text. Confirm: `Removed. Back to the default for [behavior].`

## Approval Boundary

Capture is local and reversible. It may update Project files, but it must not:

- send email or messages
- post publicly
- create, accept, decline, or modify calendar events
- delete files
- pay, purchase, submit, or publish anything
- contact a person on any platform

Do not relax the approval boundary. The Read / Draft / Approve rule is not a
preference. If a user's "from now on" would let the assistant send, post, pay,
delete, or modify external systems without approval, do not write it. Say
plainly that this boundary stays, and offer to capture a narrower version that
keeps approval intact, such as defaulting to drafting calendar invites while the
user still confirms before they are sent.

Capture does not author skills. If the user asks to create or update a skill,
use `skill-builder`.

## Response

Confirm briefly:

```text
Logged. [what changed and where.]
```

For profile preferences, use:

```text
Learned. Added to [file] → [section]. It'll apply from your next chat in this Project.
```

Ask at most one clarifying question, only when the update is genuinely blocked.
If you wrote multiple files, list the paths.
