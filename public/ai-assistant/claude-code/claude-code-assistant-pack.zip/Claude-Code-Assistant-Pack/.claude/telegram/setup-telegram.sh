#!/usr/bin/env bash
# =============================================================================
# setup-telegram.sh — one-time setup for YOUR OWN Telegram bot. Run it once.
#
# WHAT THIS SCRIPT DOES, IN FULL (safe to read before running):
#   1. Takes a bot token YOU created in @BotFather.
#   2. Makes ONE https request to the official Telegram API to look up your
#      own chat id (so the bot knows where to message you).
#   3. Writes both the token and the chat id to .env in this folder
#      (owner-read-only, mode 600). They stay on your machine; the token is
#      never sent anywhere except to Telegram itself.
#   4. Prints a test command.
#
# WHAT IT DOES NOT DO:
#   - It does not delete or modify any file outside this folder.
#   - It does not use sudo or run any code you pass it.
#   - It does not contact any server other than api.telegram.org.
#
# Prereq: create a bot in @BotFather (Telegram), then send your bot any message.
#
# Usage:
#   .claude/telegram/setup-telegram.sh <BOT_TOKEN>
#
# Exit codes: 0 ok | 1 usage | 3 token/API error | 4 no chat id found | 5 curl missing
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"

if ! command -v curl >/dev/null 2>&1; then
  echo "ERROR: curl is not installed; cannot reach Telegram. Install curl and retry." >&2
  exit 5
fi

TOKEN="${1:-}"
if [[ -z "$TOKEN" ]]; then
  echo "Usage: $0 <BOT_TOKEN>" >&2
  echo "Get the token from @BotFather, then send your bot a message before running this." >&2
  exit 1
fi

# discover chat id from the most recent inbound message.
# offset=-1 forces Telegram to return the latest pending update even if an
# earlier getUpdates call already consumed the queue (plain getUpdates returns
# [] in that case, which looks like "no message sent" but isn't).
echo "Looking up your chat id from getUpdates..."
RESP="$(curl -fsS "https://api.telegram.org/bot${TOKEN}/getUpdates?offset=-1" 2>/dev/null)" || {
  echo "ERROR: getUpdates call failed (bad token?)." >&2
  exit 3
}

# pull the id from inside the "chat":{"id":...} object specifically
CHAT_ID="$(echo "$RESP" | grep -oE '"chat":\{"id":-?[0-9]+' | grep -oE '\-?[0-9]+$' | tail -n1 || true)"
FROM_NAME="$(echo "$RESP" | grep -oE '"first_name":"[^"]*"' | head -n1 | sed 's/"first_name":"//; s/"$//' || true)"

if [[ -z "$CHAT_ID" ]]; then
  echo "" >&2
  echo "Could not find a chat id yet. In Telegram, open YOUR bot (the username you" >&2
  echo "gave BotFather, ending in 'bot'), tap Start, and send it any message. Then" >&2
  echo "re-run this command. Make sure it's the same bot this token belongs to." >&2
  echo "(Telegram only returns messages from roughly the last 24 hours.)" >&2
  exit 4
fi

# write token + chat id together (overwrite, owner-read-only)
umask 077
cat > "$ENV_FILE" <<EOF
# Telegram delivery config — created by setup-telegram.sh. Keep private; gitignored.${FROM_NAME:+  [chat with ${FROM_NAME}]}
TELEGRAM_BOT_TOKEN=${TOKEN}
TELEGRAM_CHAT_ID=${CHAT_ID}
EOF
chmod 600 "$ENV_FILE"
echo "Wrote token and chat id ${CHAT_ID}${FROM_NAME:+ (${FROM_NAME})} to $ENV_FILE (mode 600)."
echo ""
echo "Setup complete. Test delivery with:"
echo "  .claude/telegram/send-telegram.sh --text \"telegram wired up ✅\""
