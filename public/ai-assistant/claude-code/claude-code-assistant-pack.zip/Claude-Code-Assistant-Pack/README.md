# Claude Code Personal Assistant Pack

Everything you need to run a practical personal assistant in **Claude Code
Desktop**, kept in plain local files you can open and inspect. It is the
file-based, file-transparent sibling of the Claude Cowork version: same skills,
same read/draft/approve boundary, but the memory lives in Markdown in your
project folder and the Daily Brief is an HTML + text file in `outputs/` rather
than a live Cowork artifact.

The assistant gets better the more you use it. `capture` keeps your world and
your profile current; `skill-builder` turns proven workflows into new skills.

## Requirements

- **Claude Code Desktop**, signed in with an active Pro or Max subscription
- A Google account with Gmail and Calendar (Microsoft 365 Business with admin
  pre-consent also works; personal Outlook does not, forward it to Gmail instead)
- macOS or Windows, and Git installed
- About 30 to 90 minutes

## What is in here

```
Claude-Code-Resource-Pack/
├── README.md                        you are here
├── .claude/
│   ├── settings.json                pre-authorizes the brief-delivery tools
│   ├── skills/                       the six skills, loaded automatically
│   │   ├── setup/                    one-pass setup: profile + connectors + scheduled task
│   │   ├── morning-brief/            the daily brief (HTML + text in outputs/)
│   │   ├── email-triage/             classify inbox, draft Gmail replies (never sends)
│   │   ├── meeting-prep/             meeting + contact + company briefs
│   │   ├── capture/                  log decisions, follow-ups, contacts, preferences
│   │   └── skill-builder/            create or edit your own skills
│   └── telegram/                     OPTIONAL: send the brief to your phone (Android-friendly)
│       ├── send-telegram.sh
│       ├── setup-telegram.sh
│       └── .env.example
└── sample-output/
    └── morning-brief-example.md     what a finished brief looks like
```

Your profile and state files are created in the **project root** by `setup` on
first run (no `workspace/` folder): `CLAUDE.md`, `USER.md`, `now.md`,
`decision-log.md`, plus `outputs/`, `meetings/`, `contacts/`, and `companies/`
as the skills need them.

## Quick start

1. **Unzip this pack** and move the folder somewhere you will keep it (Documents
   is fine). This folder is your assistant's home.
2. **Open it as a Claude Code project.** In Claude Desktop, open the **Code** tab
   and open this folder. Approve the trust prompt; the skills in `.claude/skills/`
   load automatically.
3. **Connect Gmail and Google Calendar** in Customize -> Connectors (read access
   is enough to start; Gmail draft creation powers email triage).
4. **Run setup:** type `/setup` (or "set up my assistant"). It interviews you
   briefly, writes your profile to the project root, and creates the weekday
   morning scheduled task that writes your Daily Brief.
5. **Run the task once** from the **Routines** sidebar (Run now), and approve the
   permissions with "always allow" so future runs do not stall.

Re-run `/setup` anytime to refresh your profile.

## How automation works on Claude Code

`setup` creates a **local scheduled task** (Routine) named `daily-brief-refresh`,
weekdays at 8:00 AM by default. When it fires it runs meeting-prep, email-triage
(drafts only), and morning-brief, and writes `outputs/YYYY-MM-DD-daily-brief.html`
and `.txt`. Local tasks run only while Claude Code Desktop is open and your
computer is awake; turn on **Keep computer awake** in Settings if you want it to
fire reliably. The task prompt also lives on disk at
`~/.claude/scheduled-tasks/daily-brief-refresh/SKILL.md` if you want to edit it.

There is no live Daily Brief artifact on this path; that is a Cowork feature. The
Claude Code version keeps the brief as a file you can read, diff, and back up.

## Optional: get the brief on your phone

Two optional, one-way, outbound-to-you-only channels. Both are set up from a
terminal session, which is a Claude Code capability the Cowork version does not
have.

- **iMessage (Mac + iPhone):** add the **Read and Send iMessages** connector in
  Customize -> Connectors. `setup` will ask for your own number or Apple ID email
  and wire the morning task to text you the brief.
- **Telegram (any phone, including Android):** run
  `.claude/telegram/setup-telegram.sh` from a terminal once to store your bot
  token and find your chat id (see `.claude/telegram/telegram-setup.md`). The
  morning task then sends your brief via `.claude/telegram/send-telegram.sh`.

Neither channel reads inbound messages or takes commands. They only send your own
brief to you.

## The boundary

The assistant may read your connected sources, draft replies and reports, and
write local files. It does not send email to other people, post publicly, delete
data, purchase anything, or change calendar events without your explicit approval.
Gmail drafts and a notification to your own phone are the only outbound writes.
