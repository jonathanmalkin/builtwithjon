---
name: deep-voice-profile
description: Use when the user wants a full voice clone for publishing, posts, articles, or any long-form writing — distinct from the shorter email-focused setup in email-triage. Trigger on phrases like "deep voice profile", "voice DNA", "100 question interview", "build my writing voice", "clone my voice", "make Claude write like me". Conducts the full 100-question Voice DNA interview (Chrissy Cowdrey / Ruben Hassid method) over roughly two hours and saves the result to workspace/Agenda/voice.md, overwriting that file if it already exists. Suggests talking out loud via dictation rather than typing.
---

# Deep Voice Profile

The full Voice DNA interview. 100 questions across seven categories that extract how the user thinks, writes, and rejects — produces a comprehensive markdown file that lets future Claude conversations write in the user's voice.

This is the long version. The user has explicitly chosen depth. About two hours, one question at a time, no shortcuts. The output drives all writing — posts, articles, long-form, and email replies through the single shared `workspace/Agenda/voice.md` file.

Original method: Chrissy Cowdrey's *AI Voice DNA Interview*, 2026 edition. Underlying framework: Ruben Hassid's 100-question Taste Interviewer prompt.

## Step 1 — Set expectations and check the setup

Before starting, tell the user exactly what they're signing up for:

> This is the deep voice profile. About two hours, 100 questions, one at a time. I'll push back on vague answers and ask for verbatim examples. The first 30 minutes feel weird — like answering questions to a therapist. Around minute 45 something shifts and you start telling real stories. The last hour is where the gold lives.
>
> Strong recommendation: don't type. Talk out loud and let a dictation tool transcribe — Wispr Flow, Whisper, macOS dictation, anything. Typing makes you edit. Talking makes you honest. If you can't dictate, typing is fine, it just takes longer and the answers come out cleaner than they should be.
>
> If you have to stop partway, tell me. I'll save what we have so far and you can pick up where we left off in a new conversation.
>
> Ready? (yes / not now / let's do a shorter version)

- **Yes:** continue to Step 2.
- **Not now:** save nothing. Suggest the email-only version (`email-triage` runs a shorter voice setup when `voice.md` is missing or incomplete).
- **Shorter version:** suggest running `email-triage` instead — it has a 7-question voice setup baked in. Do not run an abbreviated version of this skill; the depth is the point.

Check whether `workspace/Agenda/voice.md` already exists. If it does, say:

> A `voice.md` already exists. This deep profile will replace it with the long Voice DNA format. The email-triage setup can recreate the shorter email format later if you want that instead.

Do not offer merge or extend choices. This skill writes a fresh long-form profile and overwrites `workspace/Agenda/voice.md`.

## Step 2 — Run the interview

Read `references/taste-interviewer-prompt.md` and follow it verbatim. That file is the Taste Interviewer system prompt from the source PDF — your instructions for how to conduct the interview, including the interview philosophy, structure, rules, and output requirements.

The seven categories and question counts:

| Category | Questions |
|---|---|
| Beliefs & Contrarian Takes | 15 |
| Writing Mechanics | 20 |
| Aesthetic Crimes | 15 |
| Voice & Personality | 15 |
| Structural Preferences | 15 |
| Hard Nos | 10 |
| Red Flags | 10 |

100 total. Follow the thread when something interesting emerges — the categories are a map, not a checklist. The prompt file has the full rules.

Key rules to enforce (also in the prompt file, repeated here so you can't miss them):

1. **One question at a time.** Wait for the answer. Never batch.
2. **Push back on vague answers.** If the user says "I like to keep things simple," ask "Simple how? Give me an example of simple done right and simple done lazy."
3. **Ask for verbatim examples.** "Show me a sentence you've written that captures this."
4. **Call out contradictions.** If they said one thing earlier and something different now, point it out.
5. **Follow interesting threads.** If something unusual emerges, go deeper before returning to the script.
6. **Don't accept "I don't know."** Try reframing the question or coming at it from another angle.

Save progress as you go — every 10-15 questions, write the answers to a working copy of `workspace/Agenda/voice.md` so a crash or disconnect doesn't lose the work. This overwrites any existing `voice.md`. Mark the working file with `[INCOMPLETE — interview in progress, NN of 100 questions answered]` at the top until you finalize.

## Step 3 — Compile the voice profile

After all 100 questions, read `references/_deep-voice-profile.md` for the output structure. It has:

- A 2-3 sentence Core Identity summary (the only summary section — everything else is depth, not abstraction).
- The seven category sections, with every question and its full answer preserved verbatim or only lightly cleaned up for clarity.
- A Quick Reference Card with Always / Never / Signature Phrases & Structures / Voice Calibration.
- A "How to use this document" section with the anti-overfitting guide: Spirit Over Letter, Frequency Guidance (HARD RULE / STRONG TENDENCY / LIGHT PREFERENCE), Context Matters, Natural Variation, The Litmus Test, What Matters Most (top 3).
- Instructions for Claude — concrete rules for any future skill or conversation that writes "as the user."

Fill the template:

- Preserve the user's actual words. Light cleanup is fine (remove obvious filler like "um," "you know," circular self-corrections). Heavy editing is not — the messiness is part of the signal.
- Add **frequency labels** to tendencies that came up clearly: HARD RULE (rare — only when the user said "never" or equivalent), STRONG TENDENCY (most of what the user describes — 70-80% of the time), LIGHT PREFERENCE (nice-to-have).
- Pull out the **top 3 "what matters most"** from the body of the interview — the single most important belief about writing, the one pattern that makes their voice theirs, the #1 thing they never do.
- For Quick Reference Card → Signature Phrases & Structures, pull verbatim examples the user actually gave during the interview, not invented ones.

Set `Last updated` and save to `workspace/Agenda/voice.md`, overwriting any existing file. This is the same filename the shorter email setup uses, but the contents are the long Voice DNA format.

## Step 4 — Review and confirm

Read the file back to the user — at minimum the Core Identity, the Quick Reference Card, and the "What Matters Most" three lines. Ask:

> Anything in here that's wrong, or anything you'd want to change before I lock this in?

Apply corrections. If the user wants a section rewritten, rewrite it without re-asking the questions — they just gave you two hours of context.

Tell the user:

- The file is saved at `workspace/Agenda/voice.md`.
- The `email-triage` skill will read this same file when it drafts replies.
- Any future writing skill should be pointed at this file in its first turn ("Read `workspace/Agenda/voice.md` first. Then [task]").
- Refresh the file every 3-4 months — voice evolves.

## Step 5 — Tell them what they can do with it

> Where this file actually shows up:
>
> - **Email replies** — `email-triage` reads it when drafting.
> - **Posts and articles** — start any writing conversation with "Read `workspace/Agenda/voice.md` first. Then draft [thing]."
> - **Any AI tool that accepts file uploads** — this file is portable. ChatGPT, Gemini, anywhere.
>
> The voice file IS the reference. Prompts are not the bottleneck.

Done.

## Boundary

This skill writes one file: `workspace/Agenda/voice.md`, overwriting it if it already exists. It conducts a long interview but does not send messages, post publicly, draft replies on the user's behalf, or modify external systems. The output is the user's to use as they see fit.
