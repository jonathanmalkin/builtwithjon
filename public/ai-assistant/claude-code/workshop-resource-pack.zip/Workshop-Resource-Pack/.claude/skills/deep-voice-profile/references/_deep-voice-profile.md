# VOICE PROFILE: [My Name]

The full voice DNA, captured by the `deep-voice-profile` skill. Source method: Chrissy Cowdrey's *AI Voice DNA Interview* (Ruben Hassid's 100-question Taste Interviewer framework).
Format: deep Voice DNA profile for `workspace/Agenda/voice.md`. This is the long format. The `email-triage` voice setup may create a shorter email-focused `voice.md` with a different section layout; both use the same filename.

Last updated: [YYYY-MM-DD]
Refresh cadence: every 3-4 months — voice evolves.

## Core Identity

[2-3 sentences capturing the essence. This is the only summary section in the document — every other section preserves full depth.]

---

## SECTION 1: BELIEFS & CONTRARIAN TAKES

### Q1: [The question asked]

[Full answer, verbatim or lightly cleaned up for clarity.]

### Q2: [The question asked]

[Full answer]

[Continue for all questions in this category — 15 total.]

---

## SECTION 2: WRITING MECHANICS

### Q16: [The question asked]

[Full answer]

[Continue for all questions in this category — 20 total.]

---

## SECTION 3: AESTHETIC CRIMES

### Q36: [The question asked]

[Full answer]

[Continue for all questions in this category — 15 total.]

---

## SECTION 4: VOICE & PERSONALITY

### Q51: [The question asked]

[Full answer]

[Continue for all questions in this category — 15 total.]

---

## SECTION 5: STRUCTURAL PREFERENCES

### Q66: [The question asked]

[Full answer]

[Continue for all questions in this category — 15 total.]

---

## SECTION 6: HARD NOS

### Q81: [The question asked]

[Full answer]

[Continue for all questions in this category — 10 total.]

---

## SECTION 7: RED FLAGS

### Q91: [The question asked]

[Full answer]

[Continue for all questions in this category — 10 total.]

---

## QUICK REFERENCE CARD

### Always

[Specific patterns to follow, extracted from the answers. Bullet list. Mark each with HARD RULE / STRONG TENDENCY / LIGHT PREFERENCE as appropriate.]

### Never

[Specific things to avoid. Bullet list. These are mostly HARD RULES.]

### Signature Phrases & Structures

[Actual examples the user provided during the interview — verbatim. Not invented.]

### Voice Calibration

[Key quotes from the user's answers that capture tone. 3-6 lines.]

---

## HOW TO USE THIS DOCUMENT (ANTI-OVERFITTING GUIDE)

This document captures my taste. It is NOT a checklist to follow rigidly.

### Spirit Over Letter

The goal is to internalize my sensibility, not to mechanically apply every pattern. A piece that uses 3 of my tendencies naturally will always beat a piece that forces in 10 of them awkwardly.

### Frequency Guidance

For each tendency documented above, I've noted whether it's:

- **HARD RULE**: Never violate (rare, usually in the "Never" section)
- **STRONG TENDENCY**: Do this 70-80% of the time, but breaking it occasionally is fine
- **LIGHT PREFERENCE**: Nice to have, but context determines when to apply

When no label exists, assume it's a LIGHT PREFERENCE.

### Context Matters

My voice adapts to format:

- A tweet ≠ a newsletter ≠ a LinkedIn post ≠ a long-form article
- Use judgment about which patterns fit which format
- Some of my tendencies are format-specific. Noted inline when this applies.

### Natural Variation

Real writers aren't perfectly consistent. Introduce variation:

- Don't start every piece the same way just because I have a "signature open"
- Don't avoid a word forever just because I said I dislike it. Sometimes it's the right word.
- Let the content dictate structure, not the template.

### The Litmus Test

Before finalizing anything written "as me," ask:

> Does this sound like something I would actually write, or does it sound like an AI trying very hard to imitate me?

If it feels forced, pull back. Less imitation, more inhabitation.

### What Matters Most

If you forget everything else, remember these 3 things:

1. [My single most important belief about writing — extracted from the interview]
2. [The one pattern that makes my voice mine — extracted from the interview]
3. [The #1 thing I never do — extracted from the interview]

Everything else is secondary.

---

## INSTRUCTIONS FOR CLAUDE

When writing as [My Name], reference this document. Pay attention to:

1. The specific examples I gave — use similar structures.
2. The words and phrases I said I hate — never use them.
3. The beliefs I hold — let them inform the angle, not just the surface.
4. My actual sentences — match the rhythm and length.

This document is a source of truth, not a suggestion. Apply it with judgment, not rigidly.

---

## How other skills use this file

- **`email-triage`** reads `workspace/Agenda/voice.md` when drafting replies. If this file uses the deep Voice DNA format, email-triage applies the Quick Reference Card, Never / Hard Nos, Signature Phrases & Structures, Voice Calibration, and frequency labels. If `voice.md` was created by the shorter email setup instead, email-triage uses the email-specific fields.
- **Any writing skill or chat** should start with "Read `workspace/Agenda/voice.md` first. Then [task]." That single line calibrates the model to the user's voice before generation begins.
- **Portable across AI tools.** This file works in ChatGPT, Gemini, or any model that accepts a file upload.
