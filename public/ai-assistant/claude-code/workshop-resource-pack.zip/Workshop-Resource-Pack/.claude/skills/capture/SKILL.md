---
name: capture
description: Use when the user says something changed or asks the agent to remember, log, capture, note, track, or follow up on a decision, priority shift, meeting outcome, person/contact update, waiting item, delegated item, completed item, reminder, or post-meeting notes. Keeps the Project's local agenda, meeting records, and contact records current without taking external action.
---

# Capture

Keep the user's local assistant state current as normal conversation unfolds. Capture is not a journal and not a transcript digest. It records the smallest useful update in the right local file so tomorrow's brief, future meeting prep, and later contact context are better.

Use this skill even when the user does not type `/capture`. If they say something changed, capture it before replying.

## Files

- `workspace/Agenda/now.md` — current cockpit: today, waiting, delegated, follow-ups, near-term notes.
- `workspace/Agenda/decision-log.md` — durable dated decisions.
- `workspace/meetings/` — meeting prep and post-meeting outcome notes.
- `workspace/contacts/` — person/contact briefs and relationship context.

Create folders or missing agenda files when needed. If an agenda template exists at `.claude/skills/interview/references/`, use it; otherwise create a minimal Markdown file.

## What To Capture

Capture these without waiting for another skill:

- decisions
- priority changes
- waiting items and follow-ups
- delegated work
- meeting outcomes or post-meeting notes
- person/contact updates
- completed items
- reminders

If the user is just thinking out loud and there is no actionable or durable update, do not write a file. Briefly say what, if anything, is worth capturing.

## Routing

### Agenda

Update `workspace/Agenda/now.md` for current work:

- **Priority change:** edit the relevant Today or priority line; remove or mark stale contradictions.
- **Waiting / follow-up:** add who, what, and the clearest date it started or is due.
- **Delegated work:** add who owns it, what they own, and when it was handed off.
- **Completed item:** mark it done with a one-line outcome instead of leaving it open.
- **Near-term note:** add only if it affects the next brief or next action.

Use absolute dates like `2026-05-28` inside files, never "today" or "yesterday."

### Decisions

Append durable decisions to `workspace/Agenda/decision-log.md` with:

- date
- decision
- reason or context
- any follow-up if needed

Also update `now.md` if the decision changes current work.

### Meetings

For meeting outcomes, post-meeting notes, or prep-relevant corrections:

1. Create `workspace/meetings/` if needed.
2. Find an existing meeting file by date, title, person, or distinctive phrase.
3. If none exists, create `workspace/meetings/YYYY-MM-DD - [Meeting Title or Person].md`.
4. Add a dated section such as:

```md
## Outcome — YYYY-MM-DD

- Source: user-supplied conversation capture
- What happened:
- Commitments / next steps:
- Open questions:
- Follow-up state:
```

Keep private readout notes separate from any outbound draft. Do not imply commitments the user did not make.

### Contacts

For person/contact updates:

1. Create `workspace/contacts/` if needed.
2. Find an existing contact file by name or obvious alias.
3. If none exists, create `workspace/contacts/[Person Name].md`.
4. Add or update a concise dated note:

```md
## Notes

- YYYY-MM-DD — [relationship context, preference, open loop, or useful fact]
```

If the identity is uncertain, create an unresolved contact file such as `workspace/contacts/unknown-[short-description].md` rather than merging into a known person without evidence.

Also update `now.md` when the contact update creates a current follow-up, waiting item, or meeting prep need.

### Reminders

If the user names a date or time for a reminder, run the `CLAUDE.md` connector and channel discovery procedure before deciding reminder delivery is unavailable. Search active and deferred capabilities for reminder/task tools, calendar reminder tools, and approved channels such as iMessage or Telegram. The reminder prompt must be self-contained, surface the reminder only, and take no external action.

If reminder creation is unavailable, log the follow-up in `now.md` and say it was not scheduled.

## Approval Boundary

Capture is local and reversible. It may update Project files, but it must not:

- send email or messages
- post publicly
- create, accept, decline, or modify calendar events
- delete files
- pay, purchase, submit, or publish anything
- contact a person on any platform

If a capture implies an outbound action, log the state and draft the message only if useful. The user sends or explicitly approves the exact action.

## Response

Confirm briefly:

```text
Logged. [what changed and where.]
```

Ask at most one clarifying question, only when the update is genuinely blocked. If you wrote multiple files, list the paths.
