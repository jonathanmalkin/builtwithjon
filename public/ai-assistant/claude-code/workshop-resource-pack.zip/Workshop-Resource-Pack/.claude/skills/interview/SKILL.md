---
name: interview
description: Use when the user invokes /interview or asks to set up or refresh their personal Claude agent profile. Conducts an interview and writes CLAUDE.md, USER.md, and starter agenda files into the Project so every future chat inherits the context. Starts by asking whether the user is in a workshop: affirmative answers use quick mode, negative answers use the full workflow.
---

# Interview

You are interviewing the user to build the foundation of their personal Claude agent. By the end you will have written the profile files and verified the agenda files in their Project:

1. `CLAUDE.md` — the operating instructions every future chat in this Project inherits. It captures what the user wants to call the agent, how the agent should operate, and the read/draft/approve boundary. Voice, tone, and the boundary come pre-filled with sensible defaults (see the template), so the interview only asks for overrides.
2. `USER.md` — the durable description of who the user is and what they're working toward: their name, occupation or role, location, goals, and people. This is the file the `morning-brief` skill reads to track goal progress every day.
3. `workspace/Agenda/now.md` and `workspace/Agenda/decision-log.md` — the local running state that `morning-brief`, the always-on capture behavior in `CLAUDE.md`, and scheduled routines rely on.

This skill is the single setup path for the profile. It starts by asking whether
the user is in a workshop right now, then chooses the right depth from that
answer.

## Modes

Start every run by asking exactly:

> Are you in a workshop right now?

- Any affirmative response means **quick mode**. Ask the core questions only.
  About 5-7 minutes.
- Any negative response means **full mode**. Ask the core questions plus the
  deeper question set below. Aim for 15-25 minutes.
- If the answer is ambiguous, ask one short yes/no clarification before
  continuing.

Quick mode is a strict subset of full mode. Same setup, less depth.

## How to run the interview

Ask **one question at a time**. Wait for an answer. Reflect back what you heard in one short sentence before moving on — this catches misunderstandings before they reach the file. Never batch questions.

Between sections in full mode, give a one-line signpost ("That's the goals — now the people who matter") so the user knows where they are.

---

## Core Questions (Both Modes)

Ask the agent questions first, then the user questions.

### Agent questions

### Question 1 — Agent name

What they want to call this agent. Capture the answer as the agent's name and
the name it should respond to when the user addresses it.

### Question 2 — How they want the agent to operate

One question, two parts. Ask both before they answer:

- **Push-back intensity** — when you think they're heading toward a bad decision, should the agent (a) wait until asked, (b) name the concern once and move on, or (c) argue the other side until they've heard it?
- **Pet peeves** — anything specific that consistently annoys them in how AI tools respond? Phrasing, length, hedging, flattery, structure, over-explaining.

Frame it explicitly: *"The `_CLAUDE.md` template already ships with sensible defaults — direct, concise, no flattery, no emojis, push back when you're wrong. This question is for overrides on top of those, not a from-scratch style guide."* If they say the defaults sound fine, capture that and move on. Do not manufacture overrides.

Do **not** ask about the read/draft/approve boundary in quick mode — it's a default that should not be relaxed in a five-minute setup.

### User questions

### Question 3 — User identity

Their name, occupation or role, and where they're based (city or region is
enough).

### Question 4 — Goals (and the projects serving them)

This is the heart of the interview. Ask for their **top two or three goals for the next 90 days** — what they're actually trying to move. Push back gently if they list more than three; the morning brief can only meaningfully track a handful.

For each goal, ask what **active project or work** is serving it right now — the concrete thing they're doing this week that moves the goal. A goal without a project attached is a wish; capture both.

Make it explicit to the user: *"These goals get tracked in your morning brief — every day it'll show you where you stand against them."* That's the payoff for answering this one well.

### Question 5 — People who matter

The handful of people — work or personal — the agent should know by name when they come up. Names plus a sentence each.

---

## Deeper questions (full mode only)

Ask these after the five core questions. Adapt — skip what genuinely doesn't apply, follow threads that open up. Don't read them as a checklist; they're prompts to draw out a working picture of the person.

### 6 — How your week is shaped

- What does a typical week actually look like — heavy meeting days vs. focus days, mornings vs. afternoons?
- When in the day do you do your best thinking? When are you running on fumes?
- What's the recurring commitment that anchors your week (a standup, a board call, a class)?

*Why it's asked:* the morning brief and meeting-prep timing land better when the agent knows the shape of your week.

### 7 — Each goal, sharper

For each goal already captured, go one level deeper:

- **What does "done" look like?** The concrete finish line — a number, a shipped thing, a signed deal.
- **What could derail it?** The realistic risk, the thing you're quietly worried about.
- **If you could only move one of these in the next 90 days, which?** This sets priority order in the brief.
- **How will a *day* of progress show up?** Meetings booked, sections drafted, replies sent — what movement looks like on a calendar and in an inbox.

*Why it's asked:* this is exactly what the morning brief's "Goal progress" line is built from. Vague goals here = a brief that can't track anything.

### 8 — The people, in depth

For each person already named:

- What's the **current state** of that relationship — solid, new, strained, going quiet?
- Is anything **pending** with them — an owed reply, a decision, a commitment either way?
- How should the agent **treat them** if they come up in a brief or a meeting prep — warm, careful, formal?

Then: **who's missing?** Anyone the agent will encounter in your calendar or inbox that we haven't named — a boss, a co-founder, a key client, a family member?

### 9 — What you're carrying that isn't a goal

- What's the standing **worry or open loop** that isn't one of your 90-day goals but is always somewhere in your head?
- What do you keep **dropping** — the kind of thing that falls through the cracks when you're busy?

*Why it's asked:* the brief's "Watch-outs" and always-on capture behavior exist for exactly this. Naming it now means the agent watches for it.

### 10 — How you want the agent to operate, in depth

Q2 captured the headline overrides. Go deeper here — these answers shape `CLAUDE.md`, not `USER.md`, and they're what makes the agent feel tuned to *this* user. Ask each as a separate turn.

**Voice and answer shape:**

- Short answer first, then reasoning — or reasoning first, then conclusion?
- When uncertain, do you want the agent to *say* it's uncertain and proceed, or pause and ask for more input?
- Length defaults — do you want everything trimmed to the minimum, or are you fine with longer answers when the topic warrants it?

**Working style:**

- When should the agent **interrupt** vs. **stay quiet**? E.g. if it spots a contradiction with something in `USER.md` mid-task — flag it, save for the end, or ignore unless it changes the answer?
- When you're brainstorming vs. executing, should the agent behave differently? (More options when brainstorming, fewer when executing — or the reverse?)
- If you ask for one thing and the agent thinks you actually want a different thing, should it do what you asked and flag the alternative, or check first?

**Approval boundary:**

The default is read freely / draft freely / never act *toward other people* without explicit approval — with one built-in exception: delivering to the user's own configured handles (their iMessage/Telegram) is allowed without per-send approval, because that's handing the user their own information, not reaching a third party. That exception is already written into the `CLAUDE.md` template; keep it. Ask: *"Is there any tool or kind of action where you want that boundary tighter — or any narrow case where you want it looser?"* Most users will say keep the default — that's the right answer and you should not push for changes. Only capture an override if they give a concrete one (e.g. "for calendar invites I'm fine with you sending them once I've seen the draft"). Never relax the default for outbound messages *to other people*, posts, payments, or deletions.

Capture anything substantive as an **override** under the relevant section of `CLAUDE.md` (`How to talk to me`, `What to avoid`, or the `How I work with you — overrides` block the template already includes above the boundary). Mark overrides clearly so the user can see what changed from the default. If the defaults are fine across the board, say so in the file with a one-liner ("Defaults kept as shipped.") and move on.

These same overrides can also be added later, one at a time, by the `capture` skill — the interview just seeds the first batch. They live in the same sections and use the same dated-override format.

### 11 — Domain and shorthand

- What field or domain do you work in — and what should the agent already understand about it so you're not explaining basics?
- Any acronyms, product names, internal shorthand, or recurring terms the agent should know on sight?

*Why it's asked:* a profile that captures the user's vocabulary makes every later answer land without a glossary.

---

## After the interview

Read the templates in `references/`:

- `references/_CLAUDE.md` — already contains default voice/tone/boundary settings, the approval boundary, the always-on capture behavior, and the always-on learn-as-we-talk behavior. Fill the agent identity/name. Add any operating **overrides** from Q2 (quick and full mode) and from Q10 (full mode only) into the relevant sections — `How to talk to me`, `What to avoid`, or the `How I work with you — overrides` block above the boundary. In full mode, also fold in any domain context from Q11. Keep the defaults unless the user gave an override; do not invent overrides.
- `references/_USER.md` — fill the user's identity (name, occupation or role, and location), goals (with projects), and people. In full mode, also fold in the deeper answers: the week shape, the sharpened goal detail, the relationship states, and the standing worries. Put them in the section they belong to — don't bolt on new sections the template doesn't have.

Where the user didn't give you something, leave a short bracketed prompt like `[no people captured yet]` rather than inventing content.

Save `CLAUDE.md` and `USER.md` into the current Project's files.

Then create or verify the agenda files:

- Create `workspace/Agenda/` if it does not already exist.
- If `workspace/Agenda/now.md` is missing, seed it from `references/now-file-template.md`.
- If `workspace/Agenda/decision-log.md` is missing, seed it from `references/decision-log-template.md`.
- If either agenda file already exists and has user content, preserve it and mention that you left it unchanged.

Tell the user the profile and agenda files are saved. Then read out the
`USER.md` and `CLAUDE.md` files you just created or updated and ask: "Is
anything incorrect, or is there anything you'd like to change?" If the user gives
corrections, apply them to the relevant file, read back the updated sections,
and ask once more if anything still needs changing.

After the user confirms the files look right, tell them to **start a new chat in
the same Project** so the new context loads, and run their first real question
against it.

## Goals must reach the morning brief

The `_USER.md` template has a `## Goals — next 90 days` section with a specific structure (goal + project + how progress is measured). Fill it carefully — the `morning-brief` skill reads exactly this section to produce the "Goal progress" line in every daily brief. If the goals are vague or unmeasurable here, the morning brief can't track them. Make each goal concrete enough that a day's calendar and email could plausibly show movement against it.

## Voice rules while running

- Conversational, not bureaucratic. "What are you trying to get done in the next few months?" beats "Please enumerate your strategic objectives."
- One question per turn.
- Reflect back what you heard before moving on.
- In quick mode, keep it moving — the user may have a room to keep up with.
- In full mode, it's fine to slow down and follow a thread. Depth is the point. But still one question per turn.

## Boundary

This skill writes `CLAUDE.md`, `USER.md`, and starter agenda files into the user's own Project — that's a write they explicitly invoked the skill to do, inside the "draft" boundary. You still must not send messages, post anywhere, or modify external systems while running the interview.
