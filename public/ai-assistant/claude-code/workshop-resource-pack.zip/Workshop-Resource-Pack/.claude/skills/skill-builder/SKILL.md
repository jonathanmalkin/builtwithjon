---
name: skill-builder
description: Use when the user wants to turn a workflow into a reusable skill, or change how an existing skill works. Trigger on "make this a skill", "save this as a skill", "turn what we just did into a skill", "build me a skill that...", "create a skill for...", "edit my [name] skill", "update my [name] skill so it also...", "change how [name] works", or "my [name] skill keeps doing X — fix it". Scaffolds a new skill folder or edits an existing one in .claude/skills/, following this pack's own conventions, and never authors a skill that takes external action without approval.
---

# Skill Builder

This is how the agent becomes self-improving: it can write and revise its own skills. A skill is just a folder under `.claude/skills/` with a `SKILL.md` file. The frontmatter tells Claude *when* to use it; the body tells Claude *how*. Optional `references/` files load only when the skill runs, so they cost nothing until needed.

The user is in Claude Code Desktop with this Project open, so writing a `.claude/skills/<name>/SKILL.md` file is all it takes — the skill becomes available in the next chat in this Project.

## Two jobs

- **Create** a new skill from a workflow the user describes or one you just did together.
- **Edit** an existing skill — change its trigger, its steps, or its references.

Detect which from the request. "Make this a skill" / "build me a skill that" → create. "Edit my X skill" / "update X so it also" / "X keeps doing Y" → edit.

## Before you write — get the shape right

Don't scaffold blind. A skill is only worth saving if it's a *repeatable* workflow with judgment in it. Confirm three things first, asking only what you can't already infer from the conversation:

1. **What it does** — the job, in one sentence.
2. **When it should fire** — the phrases or situations that should trigger it. This becomes the `description`, which is the single most important field: Claude reads only the name + description to decide whether to invoke a skill, so it must name the real trigger phrases.
3. **The steps** — the actual workflow. If you just did this work together, you already have them; replay them back as a numbered list and let the user correct. If it's described from scratch, draw the steps out, but don't over-ask — capture the spine and note where judgment is needed.

If the "skill" is really a one-off task or a preference about behavior, redirect: a behavior preference belongs in `CLAUDE.md` via the `capture` skill, not in a skill folder. A pure one-off doesn't need saving at all.

## Conventions this pack uses — match them

Read one or two existing skills in `.claude/skills/` before writing (e.g. `morning-brief/SKILL.md`, `capture/SKILL.md`) and mirror their shape. The house style:

- **Frontmatter:** exactly two fields, `name` and `description`. `name` is kebab-case and matches the folder name. `description` starts with "Use when…", names concrete trigger phrases, and says what the skill produces. Write it for *matching*, not for marketing.
- **Body:** a short `# Title`, a one-paragraph statement of the job, then the workflow. Use imperative voice ("Read the calendar", "Draft the reply"), numbered steps where order matters, and short sections. Explain judgment calls, not keystrokes.
- **References:** if the skill needs a template or a long reference, put it in `references/` and point to it from the body. Reference files in this pack are prefixed with `_` when they're templates the user fills in (e.g. `_CLAUDE.md`). Keep `SKILL.md` lean; push bulk into references.
- **Absolute dates** inside any files the skill writes (`2026-05-28`, never "today").
- **The approval boundary is inherited.** Every skill in this pack obeys Read / Draft / Approve. Any skill you author that touches email, calendar, messages, posting, payments, or deletion must draft-and-stop, never send. State that boundary in the skill body explicitly, the way the existing skills do.

## Creating a new skill

1. Pick a kebab-case name. Check `.claude/skills/` — if a skill with that name exists, switch to edit mode instead of clobbering it.
2. Create `.claude/skills/<name>/SKILL.md` with the frontmatter and body, following the conventions above.
3. If it needs a template, create `.claude/skills/<name>/references/<file>.md` and reference it from the body.
4. Show the user the `SKILL.md` you wrote — at minimum the frontmatter and the step list — and ask if the trigger and steps are right.
5. After confirmation, tell the user: the skill is saved, and it'll be available in the **next** chat in this Project (the current chat's skill list is already loaded). They can invoke it with `/<name>` or just by describing the task.

## Editing an existing skill

1. Read the current `.claude/skills/<name>/SKILL.md` in full.
2. Make the smallest change that does the job. Changing *when* it fires → edit the `description`. Changing *what* it does → edit the relevant body section. Don't rewrite a working skill to change one step.
3. If the user is reporting a misfire ("it keeps doing X"), find the line responsible and fix that line; don't bolt on a contradicting instruction.
4. Show the diff in plain terms — "I changed the description to also trigger on 'X', and added a step that does Y" — and confirm before/after writing.
5. Note that the change takes effect in the next chat in this Project.

## Register it where it belongs

If the new or edited skill is one the user will rely on routinely, offer to add it to the `## Saved skills I rely on` list in `CLAUDE.md` so the profile points at it. Don't do this silently — it's a `CLAUDE.md` edit; mention it and let the user say yes. (This is the same kind of profile write the `capture` skill makes.)

## Quality bar before you save

- The `description` names real trigger phrases a user would actually say.
- The steps are specific enough that a fresh chat could follow them cold.
- No invented tool calls — if the skill needs Gmail, Calendar, iMessage, Telegram, or any other connector/channel, include an explicit discovery preflight that follows the pack's `## Connector and channel discovery` note in `CLAUDE.md`: active list, deferred list, alias search, harmless probe, then fallback.
- The approval boundary is stated if the skill touches anything external.
- It's genuinely reusable. If it isn't, say so and don't create skill clutter.

## Boundary

`skill-builder` writes only inside `.claude/skills/` in the user's own Project — a local, reversible, draft-boundary write the user explicitly directed. It never sends, posts, modifies external systems, or authors a skill that does those things without approval. Show the user what you wrote before relying on it.
