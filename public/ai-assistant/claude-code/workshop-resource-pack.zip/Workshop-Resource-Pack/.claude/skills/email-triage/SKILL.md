---
name: email-triage
description: Use when the user wants to clear their inbox, see what needs attention, or get Gmail drafts ready for replies. Trigger on phrases like "triage my inbox", "what emails need attention", "draft replies to my recent emails", "clear my inbox", or "what's waiting for me". Probes active and deferred connectors first so lazy-loaded Gmail/Calendar tools are found, uses only workspace/Agenda/voice.md as the voice source, runs the voice setup gate before drafting if voice.md is missing or incomplete, reads all Gmail threads from the last 48 hours, including read and unread mail, classifies each as Reply Needed / FYI / Archive / Ignore, creates a Gmail Draft for each Reply Needed thread, prints each draft in chat, and confirms the Gmail drafts were created. The agent never sends — the user reviews drafts and sends from Gmail.
---

# Email Triage

Classify recent inbox threads and create Gmail Drafts for the ones that need attention. Also print the draft text in chat so the user can review without opening Gmail. The user reviews and sends. **You never send.** This is the strictest version of the read/draft/approve boundary.

## Step 1 — Connector discovery preflight

Run the `CLAUDE.md` connector and channel discovery procedure before deciding Gmail or Calendar is unavailable. Search active and deferred capabilities for:

- **Gmail** — `Gmail`, `Google Mail`, `mail`
- **Google Calendar** — `Google Calendar`, `calendar`, `gcal`

Use harmless probes:

- Gmail: search or read recent threads. Also inspect whether draft creation is exposed, but do not create a dummy draft just to test.
- Calendar: list or search relevant events only when a thread is about scheduling.

Report one short status line:

- **Gmail** — available / available but needs permission / not exposed in this session; draft creation available?
- **USER.md** — present? (For identity and the people who matter.)
- **Google Calendar** — available / available but needs permission / not exposed in this session. (Useful for threads that are about scheduling.)

If Gmail is not exposed after active and deferred discovery, this skill can't run against the inbox. Tell the user which connector to enable and stop. If Gmail can read but cannot create drafts, produce chat drafts only and clearly say Gmail draft creation was unavailable.

## Step 2 — Voice setup gate

Run this gate on every email-triage invocation before pulling recent threads or drafting replies. The point is to make sure reply drafts have a real voice source, not workshop defaults by accident.

Check only `workspace/Agenda/voice.md` and report the result in the final triage output as `Voice source: ...`.

- **`voice.md` is missing:** read `references/voice-setup.md` and follow it end-to-end. It handles the privacy consent gate, the sent-folder scan and filtering, voice extraction, the 3-question augmentation, the interview-only fallback, and saving `workspace/Agenda/voice.md`.
- **`voice.md` exists:** read it before pulling threads. Do not look for or read any other voice file.

Use the email setup format. It usually starts with `# Voice — how I write email` and includes `Source: sent-email corpus...` or `Source: interview only...`. Apply the email-specific sections directly: Greeting and sign-off, Default length, Warmth by relationship, How I say no, Phrases I never use, Punctuation and rhythm, and Sample replies.

Treat `voice.md` as incomplete if it is marked `[INCOMPLETE`, if major sections are still bracketed placeholders, if it has no `Source:` line, or if it has no sample replies. If it is incomplete, run `references/voice-setup.md` to repair it before triage unless the user explicitly declines.

If the user cancels voice setup, continue only with the Step 5 workshop-default fallback and mark the final output clearly: `Voice source: workshop defaults — voice setup cancelled`.

## Step 3 — Pull recent threads

Default scope: all Gmail threads with activity in the last 48 hours, including both read and unread mail. Do not limit the search to `is:unread`; read messages can still need action. If the connector supports All Mail search, use it so recently archived or already-read threads are not missed. Also include any older thread the connector surfaces where the user is clearly the next responder.

This wider scan will surface more handled mail. That is expected — classify those threads as FYI, Archive, or Ignore rather than drafting unnecessary replies.

Skip:

- Newsletters and marketing.
- Automated notifications (build failures, login alerts, receipts) unless they look genuinely urgent.
- Threads where the user has already replied and is waiting on the other party.

If the user specified a different scope ("last 24 hours", "everything from this client"), honor it.

## Step 4 — Classify each thread

Four classes, applied honestly:

- **Reply Needed** — the user is the next responder and the thread is moving. Draft a reply (step 5).
- **FYI** — the user should know it exists but doesn't need to act. One-line summary.
- **Archive** — it's done, the thread resolved itself, or the user was CC'd on something that doesn't need their attention.
- **Ignore** — slipped through the newsletter/notification filter. No reply, no summary, just acknowledged once and moved on.

Be willing to mark things Archive or Ignore. If everything reads as Reply Needed, your triage is broken — recalibrate.

## Step 5 — Draft replies (Reply Needed only)

For each Reply Needed thread, write a draft.

**If `workspace/Agenda/voice.md` exists**, apply the email-specific fields as direct drafting rules:

- **Open with their greeting pattern.** Don't substitute "Hi" if they use first-name-only or no greeting.
- **Close with their sign-off.** Don't add "Best regards," if they sign off with their initial.
- **Match their default length.** Most replies should fit their typical range. Save longer drafts for threads that genuinely warrant it.
- **Calibrate warmth from the relationship.** Use the close / professional / cold dial — pick the closest match for this sender. Cross-reference `USER.md`'s People section when the sender is named there.
- **Never use a phrase in their "never use" list.** Treat this as a hard rule, not a preference.
- **Match their punctuation habits.** If they don't use em-dashes, don't use em-dashes. If they don't write "do not," contract it.
- **Use the sample replies as the dominant style signal.** When in doubt about phrasing, ask "would this fit in the three samples?"
- **Respect any `Override:` lines** the user added — these take precedence over corpus-derived patterns.

**If `voice.md` is missing or unusable because the user cancelled voice setup in Step 2**, fall back to these workshop defaults:

- Direct and concise. Most replies 1-4 sentences.
- No "Hope this finds you well" / "Just circling back" / "I wanted to reach out" openers.
- No emojis or exclamation points unless the sender used them first.
- Match the sender's greeting pattern as a proxy (if they wrote "Hey Jonathan —", echo that register).
- Plain sign-off ("Thanks," or no sign-off).
- Add a one-line note at the top of the triage output: "Drafts use workshop defaults — set up voice profile with the voice setup step for tighter matching."

Each draft should be ready for the user to review and send from Gmail. If a thread can't be drafted because it needs information the user has to provide (a decision, a number, an attachment), say so explicitly in place of the draft — don't invent the missing piece, and don't create a placeholder Gmail draft for that thread.

## Step 6 — Create Gmail Drafts and verify

For each Reply Needed thread with a complete draft:

- Use the Gmail connector's draft creation capability to create a draft reply in Gmail.
- Create the draft in the original thread when the connector supports thread-aware drafts. Preserve the subject and intended recipients from the thread. Do not add CC/BCC recipients unless they were already part of the thread or the user explicitly requested them.
- Do **not** send the message. Do **not** mark the thread read. Do **not** archive it. Do **not** apply labels. The only mailbox write allowed by this skill is creating the Gmail Draft.
- Capture the confirmation the connector provides: draft id, thread id, subject, recipients, or a successful tool result. Never claim a Gmail draft was created unless the Gmail tool confirmed it.
- If draft creation fails for a thread, still print the draft in chat and mark that item clearly as "Gmail draft not created", with the reason if available.

Use this Drafts folder link in the final response:

`https://mail.google.com/mail/u/0/#drafts`

If the user has more than one signed-in Google account, tell them to switch Gmail to the account connected to Claude if the link opens the wrong inbox.

## Step 7 — Produce the triage output

Read `references/email-triage-output-template.md` and fill it. Return one structured response.

The output must include:

- The full draft text printed in chat for every Reply Needed thread.
- A per-thread Gmail draft status: created, not created, or skipped because key information was missing.
- A clear confirmation line near the top: "Gmail drafts created: [created count]/[draftable Reply Needed count]."
- A clear voice line near the top: "Voice source: [voice.md — email setup / workshop defaults — voice setup cancelled]."
- A clickable link to Gmail Drafts: `[Open Gmail Drafts](https://mail.google.com/mail/u/0/#drafts)`.
- A final reminder: "Nothing was sent."

## Hard rule: create drafts, never send

This skill is allowed to create Gmail Drafts. That is the only mailbox write it is allowed to perform.

You **do not** use the Gmail send-email tool. You **do not** mark threads read, archive them, delete them, or apply labels. The user opens Gmail Drafts, reviews the drafts, edits if needed, and hits send themselves.

Always print the draft text in chat too. A Gmail Draft without a chat copy is not enough for this workflow, because the user needs an auditable review surface inside the triage result.

## Voice calibration

If after a triage the user says "this doesn't sound like me," ask one or two questions about what was off and update `workspace/Agenda/voice.md` with the answer. Voice gets better with each correction — bake it into the file, not into a one-off note.

If the gap is consistently in a section that's still empty or bracketed (e.g., the user skipped giving sample replies), offer to redo just that part of the interview rather than starting over.
