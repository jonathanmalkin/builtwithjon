---
name: teach
description: Use when the user expresses a lasting preference about how the agent should behave — "stop doing that", "from now on", "always/never", "I prefer", "remember that I like/hate", or corrects the agent's style, tone, length, or format in a way that should stick beyond this chat. Writes the preference as a marked override into CLAUDE.md (how the agent behaves) or USER.md (a durable fact about the user), so it survives into every future chat. The mirror image of `capture`: capture records facts about the user's work, teach records preferences about how the agent works.
---

# Teach

`capture` keeps the user's *world* current — decisions, follow-ups, contacts. `teach` keeps the *agent* current — how it talks, what it avoids, what it should always or never do. Both pull durable signal out of ordinary conversation so the user never has to re-explain. Capture writes to `workspace/`. Teach writes to the profile files: `CLAUDE.md` and `USER.md`.

A preference is worth teaching when it would change how a *future, unrelated* chat behaves. "Make this email shorter" is a one-off edit — not a preference. "Stop padding your answers, always lead with the conclusion" is a preference — it should change every answer from now on.

## When to use this skill

Trigger on lasting-preference signals, even without `/teach`:

- **Standing instructions:** "from now on", "going forward", "always", "never", "by default", "every time".
- **Corrections that generalize:** "stop doing X", "quit X-ing", "you keep doing X" — where X is a behavior, not a fact about a specific task.
- **Stated preferences:** "I prefer", "I like it when you", "I hate when you", "don't ever".
- **Identity/context that should persist:** "remember I'm based in", "my co-founder is", "I work in X so assume Y" — durable facts route to `USER.md`, not `CLAUDE.md`.

Do **not** trigger on one-off edits to the current artifact ("make this paragraph tighter", "redo that as a list"). Those are task instructions, not preferences. If unsure whether something generalizes, ask one short question: *"One-off, or should I make this the default from now on?"*

## How to run

This skill is **propose-then-write**. It edits the agent's own operating instructions, so the user sees the exact line before it lands. The flow is fast — one confirm, not an interview.

1. **Restate the preference as one rule.** Compress what the user said into a single imperative line, the way the `CLAUDE.md` defaults are written. Example: user says "I really don't need you summarizing everything you just did at the end, I can read it" → rule: *"Don't append a summary of what you just did at the end of a response."*

2. **Pick the destination file and section** (see Routing below).

3. **Show the user the exact edit before writing:**

   > I'll add this to `CLAUDE.md` under **What to avoid**:
   > - *Don't append a summary of what you just did at the end of a response. (override — added 2026-05-28)*
   >
   > Good as-is?

4. **On confirmation, write it.** On a tweak, adjust and write. If the user says it was a one-off after all, don't write anything.

5. **Confirm briefly:** `Learned. Added to CLAUDE.md → What to avoid. It'll apply from your next chat in this Project.`

Remind the user once, the first time you write a profile edit in a session, that profile changes load on the **next** chat in the Project — the current chat already has the old version in context.

## Routing — which file, which section

### CLAUDE.md — how the agent behaves

Most preferences land here. Match the preference to the closest existing section:

- **Tone, answer shape, length, when-I'm-wrong, uncertainty** → `## How to talk to me`
- **Things to stop doing — emojis, flattery, hedging, re-explaining, padding** → `## What to avoid`
- **Working style that isn't tone or avoidance** — when to interrupt, brainstorm vs. execute, ask-first vs. do-and-flag → if a `## How I work with you — overrides` block exists, add there; if not, create that block directly above the `## Read / Draft / Approve` boundary.

### USER.md — durable facts about the user

If the "preference" is really a *fact* about who the user is or their context, it belongs in `USER.md`, not `CLAUDE.md`:

- Identity, role, location → `## Identity`
- A person who should be known on sight → `## People who matter`
- A goal or project shift → `## Goals — next 90 days` (but a substantive goal change is better handled by re-running `interview`)
- Domain shorthand / vocabulary → if the template has a domain section use it; otherwise note it under `## Identity` as a one-liner.

When in doubt: *does this describe the user, or instruct the agent?* User → `USER.md`. Agent → `CLAUDE.md`.

## How to write the edit

- **One line, imperative, matches the file's existing voice.** Read the surrounding bullets and match their style. Don't write a paragraph where the defaults are one line each.
- **Tag every change as an override with a date** so the user can always see what they changed vs. what shipped: `(override — added YYYY-MM-DD)`. Use absolute dates.
- **Reconcile, don't pile up.** Before adding, scan the target section for a default or earlier override that this contradicts. If the new preference *replaces* an old line, edit that line (and note it: `(override — revised YYYY-MM-DD)`) rather than leaving two rules that fight. If it *narrows* a default, keep the default and add the exception beneath it.
- **Don't relax the approval boundary.** The Read/Draft/Approve rule is not a preference. If a user's "from now on" would let the agent send, post, pay, delete, or modify external systems without approval, do not write it. Say plainly that this boundary stays, and offer to capture a narrower version that keeps approval intact (e.g. "I can default to *drafting* calendar invites for you, but you still confirm before they're sent").

## Forgetting

If the user says "stop doing that / never mind / undo that preference / go back to default", find the matching override line and remove it (or restore the shipped default text). Confirm: `Removed. Back to the default for [behavior].`

## Boundary

`teach` writes only to `CLAUDE.md` and `USER.md` inside the user's own Project — a local, reversible, draft-boundary write the user is explicitly directing. It never sends, posts, modifies external systems, or relaxes the approval boundary. It does not touch `workspace/` files — that's `capture`'s job — and it does not author skills — that's `skill-builder`'s.
