---
name: meeting-prep
description: Use when the user has meetings coming up and wants prep for a time period, day, named event, or person/event filter. Trigger on phrases like "prep my meetings tomorrow", "meeting prep for today", "prep me for my meetings with X", "I have a 2pm with [name] — get me ready", "meeting prep for [calendar event]", "what do I need for my next meeting", or "I'm meeting [name] tomorrow". Probes active and deferred connectors first so lazy-loaded Calendar/Gmail tools are found, discovers every matching meeting in the specified time period or the default window, never asks the user to choose among multiple matching meetings, creates a meeting prep doc for every discovered meeting, and creates or updates a contact brief for every non-user attendee in every discovered meeting.
---

# Meeting Prep

This skill is the compounding moment from lesson 16 — it discovers the user's upcoming meetings, researches every non-user attendee, reads the user's profile, and turns the window into meeting prep docs plus attendee contact briefs.

The unit of work is a meeting window, not a single hand-picked event. If multiple meetings match, process all of them. Contact briefs are part of meeting prep: every person in every discovered meeting gets a contact brief, even when the user asked about only one event title or one attendee.

## Step 1 — Connector discovery preflight

Run the `CLAUDE.md` connector and channel discovery procedure before deciding any tool is unavailable. Do this even if Calendar or Gmail does not appear in the initially active tools list.

Search active and deferred capabilities for these aliases:

- **Google Calendar** — `Google Calendar`, `calendar`, `gcal`
- **Gmail** — `Gmail`, `Google Mail`, `mail`
- **Google Drive** — `Google Drive`, `Drive`
- **Web search** — `web search`, `search`, `browser`

Use harmless probes:

- Calendar: list or search the event window the user named. If no window is specified, use the default window: the next 24 hours from invocation in the user's local timezone.
- Gmail: search for recent threads or calendar invites involving the named person, event title, or meeting domain.
- Drive: search only for docs linked from the event or named by the user.

One short line at the top of your work:

- **Web search** — available / available but needs permission / not exposed in this session
- **Google Calendar** — available / available but needs permission / not exposed in this session
- **Gmail** — available / available but needs permission / not exposed in this session
- **Google Drive** — available / available but needs permission / not exposed in this session
- **USER.md** — present / missing

Do not ask the user to paste event details until Calendar is absent from both active and deferred discovery, the harmless probe fails, or the user declines a needed permission prompt.

## Step 2 — Identify the time window and meetings

The user may give you:

- A specific time ("my 2pm today", "the Thursday meeting with Sarah")
- A time period ("tomorrow", "today", "next week", "May 31", "between 1 and 5")
- A person's name or company as a filter ("prep my meetings with Roger")
- A calendar event title or partial title

Resolve calendar references in the user's local timezone. If no time period is specified, default to the next 24 hours from invocation.

Use Google Calendar to find every event in the resolved window. If the user supplied a person, company, or title filter, apply it inside that window. Never ask the user to choose among multiple matches. Multiple matches are the point: process all of them.

If Calendar is not exposed after the preflight, use Gmail invites, local meeting files, and the user's pasted details as fallback evidence for the same window. Ask the user to paste event details (title, time, attendees, description, location/link) only when those sources still do not identify any meetings. Don't refuse to run.

If no meetings are found in the specified or default window, say exactly which window you checked and ask for a broader time period or event details.

## Step 3 — Gather

For each discovered meeting:

- Pull the event title, time, location/link, duration, attendees, description, agenda, attached docs, and any prior thread linked from it.
- Identify every non-user attendee. If the user has multiple accounts or aliases, use `USER.md`, the calendar organizer, and obvious self-addresses to avoid briefing the user about themself.
- If an attendee has only an email address and no clear name, still create a contact brief keyed by email address or company/domain rather than skipping them.
- If two meetings overlap or the user is double-booked, flag it in both the meeting prep and final handoff.

For every unique non-user attendee across all discovered meetings:

- Research them directly using only these augmentation lanes, in this order:
  1. **Owned context:** Gmail threads, Calendar history, Drive/docs linked from events, local `workspace/meetings/`, existing `workspace/contacts/`, `workspace/Agenda/`, and Project files.
  2. **Public professional footprint:** company bio, team page, personal website, newsletter, blog, podcast appearances, YouTube talks, event speaker pages, conference agendas, press releases, portfolio pages, and public product/company pages.
  3. **Public social/content signals:** public X/Twitter profile, LinkedIn public snippets if accessible, Bluesky, Mastodon, Substack, Medium, Reddit, Hacker News, Product Hunt, and other public writing or community posts.
- If LinkedIn or another expected source is unavailable, say so. Do not infer job titles, tenure, or relationships from thin signal.
- Search Gmail for the most recent thread with each attendee when Gmail is available — find unresolved questions, last commitments, anything stale.
- Search calendar history for prior meetings with that attendee when Calendar is available.
- Create one contact brief per unique person. If a person appears in multiple meetings in the window, update one contact brief and list each relevant meeting in it.
- Every factual claim in a contact brief should have an inline source mention when it comes from research. Use clickable Markdown links for web sources and local file links for Project sources. For connector-only evidence that cannot be clicked directly, mention the connector and stable identifiers available, such as event title/date or Gmail subject/date.

For the whole batch:

- Read `USER.md` for the user's current priorities and what they care about with these people.

## Step 4 — Synthesize

For each discovered meeting, read `references/meeting-prep-template.md` and fill it. Keep each meeting prep doc one page. The user will read it 10 minutes before the meeting, not three days early. Use the attendee contact brief work to sharpen:

- who is in the room and why they matter
- what each party needs
- the opener
- open threads going in
- the questions to ask
- risks

For each unique non-user attendee, read `references/contact-brief-template.md` and fill it. The useful shape is:

- **Who they are** — one tight sentence: role, company, why the user is talking to them.
- **Meetings in this prep window** — every discovered meeting this person appears in.
- **Source coverage** — counts for owned context, public professional footprint, and public social/content signals used in this brief.
- **What they care about** — grounded in what they write, say, or build.
- **Recent signal** — what they've been doing, writing, or shipping in the last 30-90 days.
- **Prior context with you** — last email thread, last meeting, open threads. Skip this section only if Gmail and Calendar are not exposed after discovery, or if permission is declined.
- **The one thing you'd miss** — the non-obvious detail worth knowing.
- **Open questions** — what the user should ask that the research couldn't answer.
- **Sources** — links or local evidence actually used.
- **Gaps / unavailable** — name missing connectors or weak sources directly.

Do not use people-search brokers, home-address sources, personal-phone scraping, family lookups, or sensitive personal attributes unless the user supplied the fact directly and it is relevant to the meeting.

## Step 5 — Save and hand off

Save every brief before returning results in chat.

- Meeting prep files go in `workspace/meetings/`.
- Contact briefs go in `workspace/contacts/`.
- Create either folder if it does not already exist.
- For a meeting prep doc, use a filename like `YYYY-MM-DD - [Meeting Title].md`.
- If multiple events on the same date have the same or confusingly similar titles, include the start time in the filename: `YYYY-MM-DD HHMM - [Meeting Title].md`.
- For a contact brief, use a filename like `[Person Name].md`.
- If a relevant file already exists, update it instead of creating a near-duplicate. Preserve useful prior context and add the new run's sources, gaps, and open questions.

Then return a compact handoff:

- the window processed
- number of meetings processed
- number of contact briefs created or updated
- saved paths for every meeting prep and contact brief
- any unavailable connectors, source gaps, double-bookings, or meetings that could not be fully researched

## Boundaries

- You do not send any pre-meeting emails, messages, or invites on the user's behalf.
- You do not accept, decline, or modify the calendar event.
- You do not contact the person, connect with them, or message them on any platform.
- You do not fabricate around missing sources. If a source is weak or unavailable, name the gap.
- If you notice the user is double-booked, flag it — don't silently resolve it.
