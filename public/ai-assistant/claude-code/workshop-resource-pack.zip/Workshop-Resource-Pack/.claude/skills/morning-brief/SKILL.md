---
name: morning-brief
description: Use when the user asks for their daily brief, morning brief, today's agenda, "what's on my plate today", "catch me up", or "what am I forgetting today". Probes active and deferred connectors/channels first, reads and updates the user's running agenda file, then composes today's calendar, recent unread email threads, and the user's profile into a concise mobile-readable brief covering today's meetings, threads needing attention, the first move, progress against the user's 90-day goals, and watch-outs. Sends the finished report to the user through every configured delivery path, the iMessage connector (send_imessage) for Apple devices and the bundled Telegram Bot API script for any phone, otherwise leaves the brief in the session. Designed to run on demand and also via a daily scheduled task (a Local routine) each morning.
---

# Morning Brief

Produce a brief the user can read on their phone over coffee. Mobile-readable, scannable, no walls of text. The brief tells them what's on the day, what those meetings need from them, and which threads are still open.

## Step 1 — Connector and channel discovery preflight

Run the `CLAUDE.md` connector and channel discovery procedure before deciding any tool or delivery path is unavailable. Do this even if Calendar, Gmail, iMessage, or Telegram does not appear in the initially active tools list.

Search active and deferred capabilities for these aliases:

- **workspace/Agenda/now.md** — present? (The running cockpit — read it first, then update it.)
- **Google Calendar** — `Google Calendar`, `calendar`, `gcal`
- **Gmail** — `Gmail`, `Google Mail`, `mail`
- **iMessage connector** (preferred for delivery) — connector/tool names such as `send_imessage`, `Read and Send iMessages`, `iMessage`, `Messages`, `Apple Messages`, or `send message`. Works in scheduled runs without a `--channels` session.
- **iMessage channel** (two-way chat only) — channel/plugin names such as `plugin:imessage`, `plugin:messages`, `iMessage`, or `Messages`. Only present when the session was launched with `--channels`; not expected in a scheduled routine.
- **Telegram** — channel, connector, or tool names such as `Telegram`, `telegram`, `plugin:telegram`, or `send Telegram`; **also** check for the bundled delivery script `.claude/telegram/send-telegram.sh` with its config `.claude/telegram/.env` (holds both the bot token and chat id). The script path uses the Telegram Bot API and works without a `--channels` session, so it is the reliable Android delivery path for scheduled runs.
- **USER.md** — present in this Project?
- **meeting-prep skill** — available? (Use it only for important, unfamiliar, or unprepped meetings.)

Use harmless probes: Calendar list/search for today's events, Gmail search/read for recent threads, and channel/connector configuration checks for iMessage/Telegram. Do not send a test message just to probe a delivery path.

In one short line, report status as `available`, `available but needs permission`, or `not exposed in this session`. For delivery, report each status separately: `iMessage channel`, `iMessage connector`, and `Telegram`.

If a critical tool (Calendar or Gmail) is missing, still produce the brief — just say at the top which sections will be thinner.

## Step 2 — Gather

- **Read `workspace/Agenda/now.md` first.** It's the running cockpit — today's priorities, what's waiting, what's delegated, and anything the user captured through the day or in last night's wrap-up. Treat it as current truth. The brief's Today and Waiting sections should reflect it, not contradict it.
- If `workspace/Agenda/now.md` is missing, create it from `.claude/skills/interview/references/now-file-template.md` if that template is available. If the template is unavailable, create a minimal file with `# Now — running cockpit`, `Last updated: [today]`, and sections for `Today`, `Waiting`, `Delegated`, `Follow-ups`, and `Notes`.
- If Calendar is available, pull today's calendar events (America/[user's local timezone] — read it from the connector, don't ask).
- If Gmail is available, look at the next 24 hours of unread or low-touch email threads. Skip newsletters and notifications. Prioritize threads where the user is the next responder or where someone is waiting on a reply.
- Read `USER.md` — specifically the `## Goals — next 90 days` section and the people the user cares about. The goals section is what the "Goal progress" line below is built from.
- For meetings today with attendees the user might not have ready context on, optionally call the `meeting-prep` skill — but only if a meeting feels important and unprepped. Don't prep every breakfast.

If `now.md` and the calendar disagree (a meeting in `now.md` that's not on the calendar, or vice versa), don't silently pick one — note the mismatch in the brief so the user can resolve it.

## Step 3 — Update `now.md`

Before writing the brief, update `workspace/Agenda/now.md` with the relevant information you just gathered. This is part of the morning-brief job, not a separate capture step.

Rules for the update:

- Preserve user-entered context. Keep existing checkboxes, waiting items, delegated items, follow-ups, and notes unless you have clear evidence they are obsolete or complete.
- Replace placeholders with real information when you have it. If the file still contains template examples like `[outcome / priority]` and today's calendar/email/profile provides real signals, remove the placeholders.
- Set `Last updated:` to today's absolute date.
- In `## Today`, keep the list to 1-3 real outcomes. Start with any still-relevant outcomes already in `now.md`, then add only the calendar/email/goal items that materially shape the day. Do not dump the whole calendar here.
- In `## Waiting`, add active email threads or commitments where someone is waiting on the user, or the user is waiting on someone else. Include who, what, and the clearest date you can infer.
- In `## Delegated`, keep work that has been explicitly handed to someone else and still needs tracking.
- In `## Follow-ups`, add dated follow-ups discovered in email, calendar notes, or existing agenda context.
- In `## Notes`, add only brief context shifts that matter for future runs.
- If `now.md` and the calendar disagree, preserve the agenda item and add a short note describing the mismatch instead of silently deleting either source.
- If there is genuinely no new relevant information, still refresh `Last updated:` and leave the rest of the file intact. Do not tell the user that `now.md` is empty or useless; make the best agenda state you can from the available sources.

Write the updated `workspace/Agenda/now.md` back to disk before composing the brief. The brief should reflect the updated file.

## Step 4 — Synthesize

Use this exact section order. It mirrors the production morning brief and the user will recognize it after a few days.

```
# Morning Brief — [day of week, Month D]

## Today
- [HH:MM AM/PM] — [meeting title] [— short note: who, what's it about, any prep state]
- [HH:MM AM/PM] — [event]
- [...]

## Meeting prep
For each meeting today that needs prep:
- [HH:MM AM/PM — meeting] — [the one thing to walk in knowing, or "prepped — see [brief]" if a research brief exists in the Project]

## Threads needing attention
- [subject / sender] — [the unresolved question, in one line]
- [...]

## First move
[The single concrete next action — usually under 15 minutes. Not a list. One thing.]

## Goal progress
For each goal in USER.md's "Goals — next 90 days" section:
- [Goal] — [where it stands: does today's calendar or recent email move it? is it being neglected? one honest line per goal]
- [...]

## Waiting on others
- [person] — [what you're waiting for, since when]

## Watch-outs
- [anything that could go wrong today, anything the user's profile says matters that the day puts at risk]
- Approval boundary stays in force: anything addressed to someone else, I draft and you send. (Delivering this brief to your own phone is the one thing sent automatically.) I never send email to others, post publicly, or move calendar events on my own.
```

The **Goal progress** section is the point of the whole brief. For each goal in `USER.md`, look honestly at whether today's calendar and recent email move it forward. If a goal has had no movement in days and nothing today touches it, say so plainly — "no movement on [goal] this week" is exactly the signal the user needs. Tie the "First move" to a goal when you can.

Keep the whole thing under one phone screen if you can. If today is genuinely heavy, be honest about it — don't compress to fake calm.

## Step 5 — Be honest about what you couldn't see

End the brief with a one-line freshness note if anything was degraded:

> *Data freshness: Calendar ok, Gmail unavailable this session, profile last updated [date].*

If everything was clean, omit the line.

## Step 6 — Deliver the finished report

After the brief is complete, send the finished Morning Brief report to the user. Two delivery families are supported, and they are not mutually exclusive — deliver through every path the user has set up, so a user who configured both an Apple and an Android destination gets the brief on both. Attempt each configured path independently; one path failing or being absent must not block the others.

**Apple devices — iMessage** (macOS only). Prefer the **iMessage connector** (the `send_imessage` tool from the Read and Send iMessages connector): it works in a scheduled Local routine without a live `--channels` session, which is what an unattended morning run needs. Only fall back to an iMessage *channel* if no connector is available and a channel happens to be live this session — the channel is built for two-way chat and won't be present in a normal scheduled run.

**Android / cross-platform — Telegram.** Two ways, in this preference order:
1. **Telegram channel/connector** — if a Telegram channel or send tool is exposed in the session, prefer it.
2. **Telegram delivery script** — otherwise, if the file `.claude/telegram/send-telegram.sh` exists, run it to send the brief: `.claude/telegram/send-telegram.sh --file <path-to-brief>` (or pipe the brief on stdin with `-`). The script reads the user's own bot token and chat id from `.claude/telegram/.env`. **This script works in a scheduled Local routine even without a live `--channels` session**, which is why it's the reliable path for an unattended morning run.

Delivery rules:

- Send only the finished Morning Brief report, only to the user, through the configured paths above. The phone version (iMessage / Telegram) may be slightly condensed for a small screen.
- Do not use Slack, Email, Gmail, Discord, or any other channel for Morning Brief delivery.
- Do not send test messages. The first outbound message is the finished report.
- If a path needs a recipient and the user's own destination is not configured, **skip that path silently** — do not guess a phone number, handle, chat id, or recipient, and do not treat a not-configured path as an error. The Telegram script already exits cleanly with a "skipped (not configured)" notice if the user hasn't set it up.
- After delivery, add one short note in chat/run summarizing each path, e.g. `Delivery: sent via iMessage; sent via Telegram.` or `Delivery: sent via Telegram; iMessage not available this session.`
- If no path at all is configured, add: `Delivery: no iMessage or Telegram path configured — brief left in this session only.`

## Tone

- Direct. The user is reading this half-awake.
- AM/PM times, not 24-hour.
- No "Good morning!" preamble. No "I hope this helps." Get to the day.
- Plain language for unresolved things. "Sarah is waiting on the contract draft from yesterday" beats "Outstanding action item re: contractual document with Sarah."

## Boundaries

This skill reads inbox, calendar, and files. It updates `workspace/Agenda/now.md`, then drafts the brief. The only outbound action this skill may take is sending the finished Morning Brief report to the user through the Step 6 delivery path. It does **not** send emails, post anything, modify any calendar event, message anyone else, or take any other action on the user's accounts. If the brief surfaces something the user needs to act on (reply to Sarah, accept the meeting), that's on the user to do — the skill flags it and stops.

## When run as a scheduled task

If this skill is invoked by a scheduled task (a Local routine) rather than an interactive chat, the output goes into the resulting run and Step 6 still applies. Don't ask the user questions during a scheduled run; make the best brief you can from what's available, deliver it through every configured delivery path (iMessage connector and/or the Telegram script), and note any data or delivery gaps in the Data freshness / Delivery lines.
