# Workshop Resource Pack — Personal Claude Agent

Everything you need to walk out of the workshop with a working personal Claude agent in **Claude Code Desktop**: eight saved skills, capture and learn-as-we-talk behavior wired through the profile template, skill reference templates, an agenda folder, meeting/contact folders, a sample morning brief, and the Voice DNA interview PDF.

The agent is built to **get better the more you use it**. Two behaviors run quietly in every chat: `capture` keeps your *world* current (decisions, follow-ups, contacts), and learn-as-we-talk keeps the *agent* current — when you correct its style or state a lasting preference, the `teach` skill writes it into your profile so you never give the same instruction twice. And when a workflow proves useful, `skill-builder` turns it into a reusable skill, or revises one you already have. You're not stuck with what shipped; the agent rewrites its own instructions and authors its own skills, on your approval.

This folder is the **resource pack** — no private-workspace references, no scripts, no channel bridge, and no infrastructure to maintain. It's designed to be opened or copied as one Claude Code Project so `.claude/skills/` and `workspace/Agenda/` stay together and the relative paths between them hold.

## Requirements

- **Claude Code Desktop**, signed in with an active Pro subscription (or Max / Team / Enterprise)
- A Google account with Calendar and Gmail (Microsoft 365 Business with admin pre-consent also works; personal Outlook does not — forward it to Gmail instead)
- macOS or Windows.
- About four hours, or about ninety minutes if you're working off the resource pack on your own

## What's in here

```
Workshop-Resource-Pack/
├── README.md                        ← you are here
├── .claude/
│   ├── skills/                      ← installed Claude Code skill folders
│   │   ├── interview/               (+ profile and agenda starter references)
│   │   ├── capture/                 (+ local state update rules)
│   │   ├── teach/                   ← learns your preferences into the profile
│   │   ├── skill-builder/           ← creates and edits skills
│   │   ├── morning-brief/           (+ references/morning-brief-template.md)
│   │   ├── meeting-prep/            (+ meeting prep and contact brief templates)
│   │   ├── email-triage/            (+ voice setup and triage output references)
│   │   └── deep-voice-profile/      (+ Voice DNA / Taste Interviewer references)
│   └── telegram/                    ← OPTIONAL: send the morning brief to your phone
│       ├── send-telegram.sh         (sends a message via the Telegram Bot API)
│       ├── setup-telegram.sh        (one-time: stores your token, finds your chat id)
│       └── .env.example             (template — your real token is never shipped)
├── workspace/Agenda/                ← starts empty; /interview creates the live agenda files
├── workspace/meetings/              ← created by capture or meeting-prep when needed
├── workspace/contacts/              ← created by capture or meeting-prep when needed
├── The AI Voice DNA Interview - AIIC.pdf
└── sample-output/                   ← what a finished brief looks like
    └── morning-brief-example.md
```

## Moving parts

Knowing which is which is most of understanding how the agent works.

| Use case | What it is | Why |
|---|---|---|
| **Profile setup** | `/interview` skill only | Setting up `CLAUDE.md` and `USER.md`. `/interview` starts by asking whether you're in a workshop right now: yes means quick setup, no means the full workflow. A branching conversation with judgment at every turn: run once to set up, re-run to refresh or deepen. Never deterministic or recurring, so it's never a scheduled task. |
| **Email triage** | Skill only | You triage when you sit down to your inbox, not on a clock. A scheduled triage would create Gmail drafts nobody asked for. Deliberately not a scheduled task. |
| **Capture** | `capture` skill, triggered by always-on `CLAUDE.md` behavior | Runs whenever something changes — a decision, a follow-up, a reminder, a meeting outcome, or a person/contact update. It keeps `workspace/Agenda/`, `workspace/meetings/`, and `workspace/contacts/` current. You do not have to type `/capture`; the profile tells Claude to use it naturally. |
| **Teach** | `teach` skill, triggered by always-on `CLAUDE.md` behavior | The mirror of capture: capture records your *world*, teach records how the *agent* should behave. When you say "stop doing that", "from now on", "I prefer", or correct its style, teach writes the preference as a dated override into `CLAUDE.md` (or `USER.md` if it's a fact about you) so the next chat already knows. It shows you the exact line before writing — it's editing the agent's own instructions. One-off edits to whatever you're working on don't trigger it; lasting preferences do. |
| **Skill-builder** | `skill-builder` skill | How the agent authors and revises its own skills. "Make this a skill", "build me a skill that…", or "edit my morning-brief so it also checks Slack" scaffolds a new skill folder or edits an existing one under `.claude/skills/`, following the same conventions as the shipped skills — and never authoring a skill that takes external action without your approval. |
| **Morning brief** | Skill, optionally run by a Local routine | The skill defines the work. If you want it every morning, create a Claude Code Desktop Local routine that asks Claude to run the `morning-brief` skill in this Project. No separate scheduled-task prompt file is bundled here. |
| **Meeting prep** | Skill | The skill discovers every matching meeting in a specified time period, or the next 24 hours by default, then writes a meeting prep doc for each meeting and a contact brief for every non-user attendee. |
| **Deep voice profile** | Skill | The long Voice DNA interview for writing voice. It writes `workspace/Agenda/voice.md`, overwriting any shorter email voice file with the long Voice DNA format. Email triage and future writing work read that same file. |

**Almost no scripts here.** The production pipeline this is adapted from used Python scripts and a macOS launchd job to manage state and run phases. Claude Code doesn't need any of that — this pack is just skills, reference files, and local agenda state. The one exception is the **optional** `.claude/telegram/` helper: two tiny shell scripts so a scheduled brief can reach an Android phone (where iMessage can't). You only touch them if you want phone delivery, they hold no secrets, and what each one does is spelled out in plain English at the top of the file. See **"Optional — get the brief on your phone (Telegram)"** below. If you want a recurring morning brief, create the Local routine in Claude Code Desktop and point it at this Project.

## How Claude Code skills work, briefly

A **skill** is a folder with a `SKILL.md` file at the top. The frontmatter (`name`, `description`) tells Claude when to invoke it; the markdown body tells Claude how to do the work. Optional `references/` files load only when the skill triggers, so the cost stays low.

Claude triggers skills when your prompt matches the description — you don't have to type the skill name. "Prep my meetings with Sarah tomorrow" triggers `meeting-prep`. "What's on my plate today" triggers `morning-brief`. "Build my deep voice profile" triggers `deep-voice-profile`. After `/interview` creates `CLAUDE.md`, ordinary updates like "Remind me Friday to send the contract" or "I met Sarah and she wants the pricing sheet" trigger `capture` through the profile instructions. (You *can* invoke explicit skills with `/skill-name` if one doesn't trigger on its own.)

## How scheduled tasks work — "Routines" in Claude Code Desktop

Claude Code Desktop has a **Routines** section in the sidebar. When you create a new routine you choose **Local** or **Remote**:

- **Local** — a scheduled task that runs **on your own machine**. It has full access to your real files: your profile, your agenda files, your skills. Use this if you create a recurring morning brief routine from this pack.
- **Remote** — runs in Anthropic's cloud against a GitHub repo. It cannot see your local files. Not used by this pack.

You pick a name, a schedule (hourly / daily / weekdays / weekly / manual), a folder, and a prompt. Each run creates a new session under the **Scheduled** section of the sidebar, and you get a desktop notification.

**One important constraint:** a Local routine only runs while Claude Code Desktop is open and your computer is awake. If your Mac sleeps through the scheduled time, the run is skipped — but on wake, Desktop does one catch-up run for the most recent missed time. Turn on **Keep computer awake** in Desktop Settings → Desktop app → General to fire closer to on-time.

You do not write cron expressions for the standard cadences — the form picks them. For odd intervals, ask Claude in plain language.

## Setup — about 15 minutes

1. **Create or open the folder / Project** — In Claude Code Desktop, open this folder as a Project, or copy the whole folder to where you want your personal agent to live. This folder already contains `.claude/skills/` and `workspace/Agenda/`. Claude Code prompts you to **trust** the folder — do so.
2. **Connect Google** — Enable the Gmail and Google Calendar connectors and authenticate.
3. **Confirm the skills are visible** — The skills are already packaged under `.claude/skills/`. If Claude Code does not pick them up immediately, restart the app or start a fresh chat in this Project.
4. **Set up your profile** — Open a chat and run `/interview`. Claude starts by asking whether you're in a workshop right now. If yes, it runs the quick setup. If no, it runs the full workflow. It interviews you — what you want to call the agent, how you want the agent to operate, your name, occupation, location, 90-day goals, and the people who matter — then writes `CLAUDE.md` and `USER.md` from the templates and creates `workspace/Agenda/now.md` and `workspace/Agenda/decision-log.md` if they are missing. At the end, it reads the profile files back to you so you can correct anything. **Then restart Claude so the new context loads.**
5. **Test against a real question** — In a fresh chat, ask something real. Notice what the agent stops asking you to re-explain.
6. **Optional — create a morning routine** — In Claude Code Desktop, create a Local routine in this Project with a plain prompt like: `Run my morning-brief skill for today.` After creating it, click **Run now** and approve its tools with "always allow" so future runs don't stall.
7. **Later — deepen the profile** — When you have 15-20 minutes, run `/interview` and answer no when it asks whether you're in a workshop. The `interview` skill then goes well beyond the basics — how your week is shaped, what could derail each goal, the state of each relationship, how you want to be pushed back on, your domain shorthand. The richer `USER.md` and `CLAUDE.md` make every brief and prep noticeably sharper. Re-run it whenever your goals or projects shift.
8. **Optional — build your deep voice profile** — When you have about two hours and want stronger long-form writing voice, run `deep-voice-profile`. The source PDF for the interview method is included in this folder.

## Optional — get the brief on your phone

By default the morning brief lands in the routine's session. If you want it pushed to your phone, there are two paths. **Telegram** works on any phone (iOS or Android) and is the simplest reliable option for a scheduled run. **iMessage** is Mac-and-iPhone only and has heavier setup. Pick whichever fits, or both. The `morning-brief` skill delivers through every path you configure and silently skips the ones you don't.

This is entirely optional. If you skip both, everything else still works; the brief simply stays in the session.

### Telegram (any phone — recommended)

The bundled Telegram path uses a free bot you create, and it works inside a scheduled Local routine **without** needing a live `--channels` session, which is what makes it reliable for an unattended 8 AM run. It needs only `curl` (preinstalled on macOS and Windows 10/11) — no Bun, no extra CLI.

#### What you'll need

- The **Telegram app** on your phone (free, iOS or Android) and a Telegram account.
- **`curl`**, which is preinstalled on macOS and on Windows 10/11. Nothing else: no Bun, no extra CLI, no Node. (The Telegram *channel plugin* in Claude Code's docs needs Bun and a always-running `--channels` session — this bundled script path deliberately avoids both.)
- This Resource Pack opened as a Claude Code Project, with a morning-brief routine already created (Setup step 6 above).

#### Step A — Create your Telegram bot (about 2 minutes)

1. In the Telegram app, search for **@BotFather** (the official bot, blue checkmark) and open it.
2. Send `/newbot`.
3. Give it a display name (anything, e.g. "My Brief Bot") and then a **username that ends in `bot`** (e.g. `my_brief_2026_bot`). Usernames must be unique, so add numbers if it's taken.
4. BotFather replies with a **token** that looks like `123456789:AAH...`. Keep this private — it controls your bot. You'll paste it once in Step B.
5. **Tap your new bot** (BotFather links it) and send it any message, like `hi`. This is required so the bot can discover your chat id in the next step.

#### Step B — Tell the pack your token (one time)

Open a terminal **in this Project folder** (in Claude Code Desktop you can ask Claude to run it for you), and run:

```bash
.claude/telegram/setup-telegram.sh <PASTE-YOUR-TOKEN-HERE>
```

This does two things and nothing else:
- Saves your token to `.claude/telegram/.env` (owner-read-only, and git-ignored so it never gets shared).
- Looks up your chat id from the message you just sent the bot and saves it alongside the token in `.claude/telegram/.env`.

If it says it couldn't find your chat id, just send your bot another message in Telegram and re-run the same command.

#### Step C — Test it

```bash
.claude/telegram/send-telegram.sh --text "Telegram wired up"
```

You should get that message on your phone within a second or two. If you do, you're done.

#### Step D — Let your routine deliver over Telegram

The `morning-brief` skill already knows to use this path: when `.claude/telegram/send-telegram.sh` exists and is configured, it sends the finished brief there automatically (in addition to iMessage if you set that up). You don't change the skill.

**Permission is already handled.** This pack ships a `.claude/settings.json` that pre-authorizes the delivery script, so a scheduled routine can run it without stopping to ask. You don't need to do anything. (If you ever want to see or change it, the line is `"Bash(.claude/telegram/send-telegram.sh:*)"` in that file. Note: `settings.local.json` is git-ignored and per-machine, which is why the shared `settings.json` is used instead.)

That's it. Tomorrow's brief shows up on your phone.

#### Is this safe to run? (short answer: yes)

These two scripts are deliberately tiny and boring. Each one opens with a plain-English block listing exactly what it does and doesn't do — read it in 20 seconds. In full:

- They read **only** the config file (`.env`) in their own `.claude/telegram/` folder. They read nothing else on your computer — not your contacts, keys, browser, or files elsewhere.
- They make **one** network call, to the official Telegram API (`https://api.telegram.org`), and nowhere else.
- They **do not** delete or modify any of your files, **do not** use admin/`sudo` rights, and **do not** run any code from the message text or from anything you pass them.
- Until you add your own token, they do nothing but print `Telegram skipped (not configured)` and exit. They never fail loudly or block your brief.

Your token is yours alone. The pack ships with a `.env.example` template, never a real token, and your real token + chat id are git-ignored so they can't be committed or shared by accident.

### iMessage (Mac + iPhone only)

If you're on a Mac and want the brief in Messages instead of (or in addition to) Telegram, use the **Read and Send iMessages connector** — an MCP connector that exposes a `send_imessage` tool the morning-brief skill can call directly. Like the Telegram script, it works in a scheduled Local routine without a live session, so it's a fine path for an unattended 8 AM brief.

> Don't confuse this with the iMessage **channel** (`plugin:imessage`). That channel is for *two-way* conversations — texting your agent and getting replies — and it only delivers while a session is running with `--channels`, which a scheduled routine doesn't have. For one-way morning delivery, the connector is the right tool; skip the channel.

**What it requires:**

- **macOS**, with an iPhone/Mac signed into the same Apple ID.
- The **Read and Send iMessages** connector added in Claude Code (it provides the `send_imessage` tool). It needs permission to control Messages — approve the macOS Automation prompt the first time it sends.
- No Bun, no `--channels` flag, no plugin install.

**Setup, in short:**

1. Add the Read and Send iMessages connector in Claude Code and grant it the Messages/Automation permission it asks for.
2. In a chat in this Project, confirm the `send_imessage` tool is available, then tell the agent who to send to — your own Apple ID email or phone number (the morning-brief skill reads this destination; it never guesses a recipient).
3. When your morning-brief routine first runs, approve the `send_imessage` tool with **"always allow"** so future scheduled runs deliver silently.

The skill will then send the brief over iMessage automatically, alongside Telegram if you've set that up too.

## The daily loop

The workflows are designed to chain into one loop:

1. **Morning brief** opens the day — reads your calendar, inbox, profile, and `now.md`, then updates `now.md` with the relevant state it finds before writing the brief.
2. **Capture** keeps the day current — every time something changes, you tell the assistant and it updates the right local file: agenda, decision log, meeting record, or contact record.
3. **Meeting prep** gives you context before important conversations and refreshes contact briefs for every attendee in the prep window.
4. **Email triage** creates Gmail Drafts for replies that need attention, prints the drafts in chat, and leaves sending to you.
5. Tomorrow's **morning brief** is better because `now.md` stayed current.

The agenda files in `workspace/Agenda/` are the shared day-to-day state. `now.md` is the running cockpit; `decision-log.md` is the durable record of decisions. They are created by `/interview` if missing. Morning brief reads and refreshes `now.md`; the `capture` skill writes agenda updates, meeting notes, and contact updates as the day changes.

## How the agent improves — without you maintaining it

The agent is designed to get sharper the more you use it, through two always-on behaviors and one on-demand one. None of it requires you to edit files by hand.

1. **It learns facts** (`capture`) — anything that changes in your world lands in the right `workspace/` file, so tomorrow's brief and next week's meeting prep are already informed.
2. **It learns preferences** (`teach`) — when you correct how it works ("stop summarizing at the end", "always lead with the answer", "from now on draft these in bullets"), it writes that as a dated override into `CLAUDE.md` so it never makes the same misstep twice. Because this edits the agent's own operating instructions, it shows you the exact line before saving. One-off edits to the thing you're working on right now *don't* trigger it — only preferences that should outlast the chat.
3. **It learns workflows** (`skill-builder`) — when something you did together is worth repeating, say "make that a skill" and the agent scaffolds a new skill folder following the same conventions as the shipped ones. Say "edit my morning-brief so it also checks Slack" and it revises the existing one. The agent literally authors and rewrites its own skills.

**Three things to know:**

- **Edits load on the next chat.** Profile and skill changes don't take effect mid-conversation — the current chat already has the old version in context. Start a fresh chat in the Project to pick up a change. (You'll be reminded each time.)
- **You can always see what changed.** Every learned preference is tagged `(override — added YYYY-MM-DD)` in `CLAUDE.md`, so the shipped defaults and your overrides never blur together. To undo one, say "go back to the default for that" and it's removed.
- **The boundary is not teachable.** The Read / Draft / Approve rule below is not a preference you can train away and not a skill the agent can author around. "From now on just send it" will be declined; the agent will offer to default to *drafting* instead, with you still approving the send.

The throughline: the version of the agent you have a month from now is one you taught, not one you re-configured.

## Your goals drive the morning brief

The `interview` skill captures two or three 90-day goals and the project serving each, and writes them into `USER.md`. The `morning-brief` skill reads that section every day and reports — in a dedicated **Goal progress** block — whether each goal is moving, stalled, or untouched. Set goals once in the interview, get an honest read every morning. Keep them concrete in `USER.md` or the brief can't track them.

## Read / Draft / Approve — the rule

Every workflow in this pack follows the same boundary, pre-filled as a default in `CLAUDE.md`:

- **Read** — the agent reads inbox, calendar, profile, files, and connected tools freely.
- **Draft** — the agent drafts replies, briefs, and prep docs for you to review and edit. For email triage, it creates Gmail Drafts and prints the same draft text in chat. Writing to your own agenda files (`now.md`, `decision-log.md`) also counts as drafting — they're local, reversible, and yours.
- **Approve** — the agent **never** sends an email, posts publicly, modifies a calendar event, deletes anything, or takes any irreversible action without your explicit approval. You hit send. You confirm the event.

Non-negotiable. The boundary is what makes the agent safe to give your inbox to.

## When something doesn't work

- **The brief is wrong / thin / off-voice** — Almost always a `USER.md` or `now.md` problem. Add the missing context; the next run picks it up. Through the day, always-on capture keeps `now.md` current for you.
- **A Local routine didn't run** — Your Mac was asleep or Claude Code Desktop was closed. It catches up once on next wake. Turn on "Keep computer awake" to reduce misses.
- **A Local routine stalled** — It hit a tool it didn't have permission for while you were away. Open it from the sidebar, approve the tool, and use **Run now** + "always allow" so future runs don't stall.
- **A skill didn't trigger** — Either the prompt didn't match the description, or the skill isn't installed. Invoke it explicitly ("use my morning-brief skill" or `/morning-brief`) and confirm the folder is in your agent directory.
- **A learned preference didn't stick** — Profile edits load on the *next* chat, not the current one. Start a fresh chat in the Project. To check what was learned, open `CLAUDE.md` and look for lines tagged `(override — added …)`. To undo one, say "go back to the default for that".
- **A new or edited skill doesn't show up** — Same reason: it loads on the next chat. Start a fresh chat in the Project, then invoke it with `/<name>` or by describing the task.

## What to do tomorrow

Run the morning brief before you sit down, either manually or with a Local routine you create. Run `meeting-prep` for tomorrow's prep window the night before. Use `email-triage` for the first 20 minutes of inbox time. When something changes during the day, tell the assistant — the always-on capture behavior is what keeps tomorrow's brief honest.

The agent doesn't get better because you read about it. It gets better because you use it and tell it what's off — and now it does the updating for you: a correction becomes a learned preference, a useful workflow becomes a new skill. Your job is to notice and say something; the agent's job is to remember.

## Credits and provenance

These skills are adapted from a production daily-assistant pipeline (the "Pam Morning Work" stack) that runs every morning in a private workspace. The original prompts have been stripped of Hermes-specific tooling, internal file paths, scripts, and operator-specific assumptions, then rewritten to run inside Claude Code Desktop using native skills and optional Local routines. The structure, section ordering, and approval-boundary language come from the original — validated against months of daily use.
